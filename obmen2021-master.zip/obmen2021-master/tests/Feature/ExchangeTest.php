<?php

namespace Tests\Feature;

use App\Events\RatesWereUpdated;
use App\Events\StatusChanged;
use App\Jobs\Pay;
use App\Jobs\UpdateRates;
use App\Models\Direction;
use App\Models\Exchange;
use App\Models\JSONRPCClient;
use App\Models\Paysystems\Bitcoin;
use Carbon\Carbon;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\MessageBag;
use Tests\TestCase;

/**
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */

class ExchangeTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    protected function prepare($try = 1)
    {
        if ($try == 1) {
            $this->artisan('db:seed');
            $price = 10000;
        } else {
            $price = 11000;
        }

        $fakerTickerPrice = [['symbol' => 'BTCUSDT', 'price' => $price]];
        $tickerPriceMock = \Mockery::mock(UpdateRates::class)->makePartial();
        $tickerPriceMock->shouldReceive('getTickerPrice')->andReturn(json_encode($fakerTickerPrice));

        Event::fake(RatesWereUpdated::class);
        $tickerPriceMock->handle();
        Event::assertDispatched(RatesWereUpdated::class);
    }

    /** @test */
    public function handle_inactive_direction_while_creating_exchange()
    {
        $this->prepare();
        $direction = Direction::getByClasses('Bitcoin', 'USDTERC20');
        $exchange = Exchange::new($direction, 0, 0, []);
        $this->assertInstanceOf(MessageBag::class, $exchange);
        $this->assertTrue($exchange->has('direction_id'));
    }

    /** @test */
    public function handle_inactive_paysystems_while_creating_exchange()
    {
        $this->prepare();
        $direction = Direction::getByClasses('Bitcoin', 'USDTERC20');
        $direction->setActive();
        $exchange = Exchange::new($direction, 0, 0, []);
        $this->assertInstanceOf(MessageBag::class, $exchange);
        $this->assertTrue($exchange->has('direction_id'));
    }

    /** @test */
    public function handle_empty_amounts_while_creating_exchange()
    {
        $this->prepare();
        $direction = Direction::getByClasses('Bitcoin', 'USDTERC20');
        $direction->setActive();
        $direction->fromPaysystem->setActive();
        $direction->toPaysystem->setActive();
        $exchange = Exchange::new($direction, 0, 0, []);
        $this->assertInstanceOf(MessageBag::class, $exchange);
        $this->assertTrue($exchange->has('amounts'));
    }

    /** @test */
    public function handle_from_amount_minimum_constraint_while_creating_exchange()
    {
        $this->prepare();
        $direction = Direction::getByClasses('Bitcoin', 'USDTERC20');
        $direction->setActive();
        $direction->fromPaysystem->setActive();
        $direction->toPaysystem->setActive();
        $direction->fromPaysystem->minimum = 1;
        $direction->fromPaysystem->update();
        $exchange = Exchange::new($direction, 0.5, 0, []);
        $this->assertInstanceOf(MessageBag::class, $exchange);
        $this->assertTrue($exchange->has('from_amount'));
    }

    /** @test */
    public function handle_from_amount_maximum_constraint_while_creating_exchange()
    {
        $this->prepare();
        $direction = Direction::getByClasses('Bitcoin', 'USDTERC20');
        $direction->setActive();
        $direction->fromPaysystem->setActive();
        $direction->toPaysystem->setActive();
        $direction->fromPaysystem->maximum = 1;
        $direction->fromPaysystem->update();
        $exchange = Exchange::new($direction, 1.5, 0, []);
        $this->assertInstanceOf(MessageBag::class, $exchange);
        $this->assertTrue($exchange->has('from_amount'));
    }

    /** @test */
    public function handle_to_amount_minimum_constraint_while_creating_exchange()
    {
        $this->prepare();
        $direction = Direction::getByClasses('Bitcoin', 'USDTERC20');
        $direction->setActive();
        $direction->fromPaysystem->setActive();
        $direction->toPaysystem->setActive();
        $direction->toPaysystem->minimum = 1;
        $direction->toPaysystem->update();
        $exchange = Exchange::new($direction, 0, 0.5, []);
        $this->assertInstanceOf(MessageBag::class, $exchange);
        $this->assertTrue($exchange->has('to_amount'));
    }

    /** @test */
    public function handle_to_amount_maximum_constraint_while_creating_exchange()
    {
        $this->prepare();
        $direction = Direction::getByClasses('Bitcoin', 'USDTERC20');
        $direction->setActive();
        $direction->fromPaysystem->setActive();
        $direction->toPaysystem->setActive();
        $direction->toPaysystem->maximum = 1;
        $direction->toPaysystem->update();
        $exchange = Exchange::new($direction, 0, 1.5, []);
        $this->assertInstanceOf(MessageBag::class, $exchange);
        $this->assertTrue($exchange->has('to_amount'));
    }

    /** @test */
    public function handle_invalid_form_constraint_while_creating_exchange()
    {
        $this->prepare();
        $direction = Direction::getByClasses('Bitcoin', 'USDTERC20');
        $direction->setActive();
        $direction->fromPaysystem->setActive();
        $direction->toPaysystem->setActive();
        $exchange = Exchange::new($direction, 0.1, 0, []);
        $this->assertInstanceOf(MessageBag::class, $exchange);
        $this->assertEquals(5, $exchange->count());
    }

    /** @test */
    /* public function can_create_exchange_and_receive_payment_and_pay()
    {
        $this->prepare();

        // Активируем направление и платежные системы для теста
        $direction = Direction::getByClasses('Bitcoin', 'USDTERC20');
        $direction->setActive();
        $direction->fromPaysystem->setActive();
        $direction->toPaysystem->setActive();

        // Делаем mock для RPC вызовов
        $rpcMock = \Mockery::mock('overload:' . JSONRPCClient::class);
        $rpcMock->shouldReceive('getnewaddress')->andReturn('35hK24tcLEWcgNA4JxpvbkNkoAcDGqQPsP');
        $rpcMock->shouldReceive('validateaddress')->andReturn(['isvalid' => true]);
        $rpcMock->shouldReceive('listsinceblock')->andReturn([
            'transactions' => [
                [
                    'category' => 'receive',
                    'confirmations' => 1,
                    'txid' => 'a7aace5cb4e7ff951b408f71f138c5e5973b91d1efd04aec034b9a116e26f8d9',
                    'amount' => 0.11,
                    'label' => '1',
                ],
            ],
            'lastblock' => '00000000000000000002f8e454e30b597a7bd01afc6c2afc17cbddfb6a67c126',
        ]);
        $rpcMock->shouldReceive('sendtoaddress')->andReturn('a7aace5cb4e7ff951b408f71f138c5e5973b91d1efd04aec034b9a116e26f8d9');

        // Создаём правильно заполненную заявку и проверяем её корректность
        $exchange = Exchange::new($direction, 0.1, 0, [
            'lastName' => $this->faker->lastName,
            'firstName' => $this->faker->firstName,
            'email' => $this->faker->email,
            'phone' => '+74951234567',
            'cryptoAddress' => '0x9fe7f933a01ae3597016056c987537120a1f856c',
        ]);

        $this->assertInstanceOf(Exchange::class, $exchange);
        $this->assertArrayHasKey('cryptoAddress', $exchange->requisites);
        $this->assertEquals(1000 * 0.97, $exchange->to_amount);

        // Проверяем, как пройдёт оплата без пересчета курса, но с измененной суммой
        $this->prepare(2);

        $bitcoin = new Bitcoin;

        Event::fake(StatusChanged::class);
        $bitcoin->receive();
        Event::assertDispatched(StatusChanged::class);

        $exchange->refresh();

        $this->assertEquals(Exchange::PAID, $exchange->status_id);
        $this->assertNotNull($exchange->pay_date);
        $this->assertEquals(0.11, $exchange->from_amount);
        $this->assertEquals(10000 * 0.97 * 0.11, $exchange->to_amount);
        $this->assertArrayHasKey('txid_in', $exchange->info);

        // Попытаемся ещё раз, но уже через день, с пересчетом курса
        $exchange->status_id = Exchange::NEW;
        $exchange->pay_date = null;
        $exchange->update();
        Carbon::setTestNow(Carbon::now()->addDay());

        $bitcoin->receive();
        Event::assertDispatched(StatusChanged::class);

        $exchange->refresh();

        $this->assertEquals(Exchange::PAID, $exchange->status_id);
        $this->assertNotNull($exchange->pay_date);
        $this->assertEquals(0.11, $exchange->from_amount);
        $this->assertEquals(11000 * 0.97 * 0.11, $exchange->to_amount);

        $pay = new Pay;
        $pay->handle();
        Event::assertDispatched(StatusChanged::class);

        $exchange->refresh();

        $this->assertEquals(Exchange::COMPLETED, $exchange->status_id);
        $this->assertNotNull($exchange->complete_date);
        $this->assertArrayHasKey('txid', $exchange->info);

    } */

    /** @test */
    public function handle_zero_total_rate()
    {
        $this->artisan('db:seed');
        $direction = Direction::getByClasses('Bitcoin', 'USDTERC20');
        $direction->setActive();
        $direction->fromPaysystem->setActive();
        $direction->toPaysystem->setActive();

        $exchange = Exchange::new($direction, 0, 1000, []);
        $this->assertInstanceOf(MessageBag::class, $exchange);
        $this->assertTrue($exchange->has('direction_id'));
    }
}
