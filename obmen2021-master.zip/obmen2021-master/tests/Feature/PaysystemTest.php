<?php

namespace Tests\Feature;

use App\Jobs\ReservesReceive;
use App\Models\JSONRPCClient;
use App\Models\Paysystem;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

/**
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */

class PaysystemTest extends TestCase
{
    use RefreshDatabase, WithFaker;

    /** @test */
    public function reserves_are_updating()
    {
        $this->artisan('db:seed');
        $paysystem = Paysystem::whereClass('Bitcoin')->first();
        $paysystem->setActive();

        $rpcMock = \Mockery::mock('overload:' . JSONRPCClient::class);
        $rpcMock->shouldReceive('getbalance')->andReturn(0);

        $updateReserves = new ReservesReceive();
        $updateReserves->handle();

        $paysystem->refresh();

        $this->assertNotNull($paysystem->total_reserve);
        $this->assertNotNull($paysystem->auto_reserve);
    }
}
