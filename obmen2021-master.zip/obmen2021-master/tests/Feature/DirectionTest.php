<?php

namespace Tests\Feature;

use App\Events\RatesWereUpdated;
use App\Exceptions\ConstraintException;
use App\Jobs\UpdateRates;
use App\Models\Direction;
use App\Models\Paysystem;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Event;
use Tests\TestCase;

class DirectionTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    /* public function base_and_total_rates_are_updating_and_correct()
    {
        $this->artisan('db:seed');

        $fakerTickerPrice = [Paysystem::all()->map(function ($paysystem) {
            return ['symbol' => "{$paysystem->currency_id}USDT", 'price' => 10000];
        })];

        $tickerPriceMock = \Mockery::mock(UpdateRates::class)->makePartial();
        $tickerPriceMock->shouldReceive('handleBinance')->andReturn(json_encode($fakerTickerPrice));

        Event::fake(RatesWereUpdated::class);
        $tickerPriceMock->handle();
        Event::assertDispatched(RatesWereUpdated::class);

        $directions = Direction::where('base_rate', '!=', 0);

        $this->assertEquals(52, $directions->count());

        $this->assertEquals(9700, Direction::getByClasses('Bitcoin', 'USDTERC20')->total_rate);
        $this->assertEquals(10300, Direction::getByClasses('USDTERC20', 'Bitcoin')->total_rate);
    } */
}
