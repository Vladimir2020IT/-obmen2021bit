<?php

namespace Tests\Unit;

use App\Exceptions\ConstraintException;
use App\Models\Direction;
use App\Models\Paysystem;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class DirectionTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function a_fromPaysystem_cannot_be_a_toPaysystem()
    {
        $this->expectException(ConstraintException::class);
        $this->expectExceptionMessage('a_fromPaysystem_is_a_toPaysystem_exception');

        $paysystem = Paysystem::factory()->create();
        Direction::factory()->create(['fromPaysystem_id' => $paysystem->id, 'toPaysystem_id' => $paysystem->id]);
    }

    /** @test */
    public function json_rates_are_valid()
    {
        $this->artisan('db:seed');
        $rates = Direction::getRatesJSON();

        $this->assertIsArray($rates);
        $this->assertEquals(count($rates['categories']), Paysystem::distinct()->count('category_id'));
        $this->assertEquals(count($rates['paysystems']), Paysystem::count());
        $this->assertEquals(count($rates['directions']), Direction::count());

        $this->assertFalse($rates['directions'][Direction::getByClasses('Bitcoin', 'USDTERC20')->id]['inverse']);
        $this->assertTrue($rates['directions'][Direction::getByClasses('USDTERC20', 'Bitcoin')->id]['inverse']);
    }

    /** @test */
    public function get_fields_returns_correct_data()
    {
        $this->artisan('db:seed');
        $direction = Direction::getByClasses('Bitcoin', 'USDTERC20');
        $this->assertCount(3, $direction->getFields());
    }
}
