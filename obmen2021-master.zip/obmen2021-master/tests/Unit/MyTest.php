<?php

namespace Tests\Unit;

use App\Models\JSONRPCClient;
use App\Models\Paysystem;
use App\Models\Paysystems\TRX;
use App\Models\Paysystems\USDTERC20;
use App\Models\Paysystems\USDTTRC20;
use App\Models\Paysystems\ZCash;
use IEXBase\TronAPI\Provider\HttpProvider;
use IEXBase\TronAPI\Tron;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class MyTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function test1()
    {
        $this->artisan('db:seed');

        $paysystem = Paysystem::whereClass('Stellar')->first();
        $class = $paysystem->getClass();
        $class->setReserves();
        $class->receive();
    }
}
