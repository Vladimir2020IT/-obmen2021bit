<?php

use App\Http\Controllers\WelcomeController;
use App\Http\Controllers\CurrencyController;
use App\Http\Controllers\DirectionController;
use App\Http\Controllers\ExchangeController;
use App\Http\Controllers\ParamController;
use App\Http\Controllers\PaysystemController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [WelcomeController::class, 'index']);
Route::get('/exchangeView/{exchange}/{hash}', [WelcomeController::class, 'exchangeView']);

Route::get('/rates', [WelcomeController::class, 'rates']);
Route::get('/fields/{direction}', [WelcomeController::class, 'fields']);
Route::post('/exchange/{direction}', [WelcomeController::class, 'exchange']);
Route::get('/exchange/{exchange}/{hash}', [WelcomeController::class, 'getExchange']);

Auth::routes();

Route::group(['middleware' => ['auth', 'can:perform-admin-actions']], function () {
    Route::get('/admin/currencies', function () {
        return view('admin.currencies');
    })->name('currencies');
    Route::get('/currencies', [CurrencyController::class, 'index']);
    Route::put('/currencies', [CurrencyController::class, 'update']);

    Route::get('/admin/paysystems', function () {
        return view('admin.paysystems');
    })->name('paysystems');
    Route::get('/paysystems', [PaysystemController::class, 'index']);
    Route::put('/paysystems', [PaysystemController::class, 'update']);

    Route::get('/admin/params', function () {
        return view('admin.params');
    })->name('params');
    Route::get('/params', [ParamController::class, 'index']);
    Route::put('/params', [ParamController::class, 'update']);

    Route::get('/admin/users', function () {
        return view('admin.users');
    })->name('users');
    Route::get('/users', [UserController::class, 'index']);
    Route::put('/users', [UserController::class, 'update']);

    Route::get('/admin/directions', function () {
        return view('admin.directions');
    })->name('directions');
    Route::get('/directions', [DirectionController::class, 'index']);
    Route::put('/directions', [DirectionController::class, 'update']);

    Route::get('/admin/exchanges', function () {
        return view('admin.exchanges');
    })->name('exchanges');
    Route::get('/exchanges', [ExchangeController::class, 'index']);
    Route::put('/exchanges', [ExchangeController::class, 'update']);
});

Route::get('/home', [HomeController::class, 'index'])->name('home');
