<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateExchangesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('exchanges', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->unsignedBigInteger('nonce')->nullable();
            $table->unsignedBigInteger('referrer_id')->nullable();
            $table->tinyInteger('status_id', false, true)->default(0);
            $table->unsignedBigInteger('direction_id');
            $table->timestamp('create_date')->default(now());
            $table->timestamp('pay_date')->nullable();
            $table->timestamp('complete_date')->nullable();
            $table->decimal('from_amount', 16, 8, true);
            $table->decimal('to_amount', 16, 8, true);
            $table->decimal('base_rate', 12, 4, true);
            $table->decimal('tariff', 10, 2);
            $table->decimal('total_rate', 12, 4, true);
            $table->decimal('profit', 12, 4, true)->default(0);
            $table->decimal('referrer_profit', 12, 4, true)->default(0);
            $table->json('form')->nullable();
            $table->json('requisites')->nullable();
            $table->json('info');
            $table->string('hash');

            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('referrer_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('direction_id')->references('id')->on('directions')->onDelete('cascade');
            $table->unique(['user_id', 'nonce']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('exchanges');
    }
}
