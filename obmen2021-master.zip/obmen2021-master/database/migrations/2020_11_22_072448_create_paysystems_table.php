<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePaysystemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('paysystems', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('category_id')->nullable();
            $table->string('currency_id');
            $table->string('class')->unique();
            $table->string('name');
            $table->decimal('total_reserve', 16, 8, true)->nullable();
            $table->decimal('auto_reserve', 16, 8, true)->nullable();
            $table->decimal('minimum', 16, 8, true)->default(0);
            $table->decimal('maximum', 16, 8, true)->nullable();
            $table->tinyInteger('is_active', false, true)->default(0);
            $table->tinyInteger('pos', false, true)->default(0);

            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent();

            $table->foreign('currency_id')->references('id')->on('currencies')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('paysystems');
    }
}
