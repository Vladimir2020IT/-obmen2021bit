<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDirectionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('directions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('fromPaysystem_id');
            $table->unsignedBigInteger('toPaysystem_id');
            $table->decimal('base_rate', 12, 4, true)->default(0);
            $table->decimal('tariff', 10, 2)->default(0);
            $table->decimal('total_rate', 12, 4, true)->default(0);
            $table->tinyInteger('is_active', false, true)->default(0);

            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent();

            $table->foreign('fromPaysystem_id')->references('id')->on('paysystems')->onDelete('cascade');
            $table->foreign('toPaysystem_id')->references('id')->on('paysystems')->onDelete('cascade');
            $table->unique(['fromPaysystem_id', 'toPaysystem_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('directions');
    }
}
