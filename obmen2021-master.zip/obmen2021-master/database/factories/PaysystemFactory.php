<?php

namespace Database\Factories;

use App\Models\Currency;
use App\Models\Paysystem;
use Illuminate\Database\Eloquent\Factories\Factory;

class PaysystemFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Paysystem::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'currency_id' => Currency::factory()->create(),
            'class' => $this->faker->word,
            'name' => $this->faker->word,
        ];
    }
}
