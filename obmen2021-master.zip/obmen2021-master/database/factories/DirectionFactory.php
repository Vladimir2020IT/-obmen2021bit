<?php

namespace Database\Factories;

use App\Models\Direction;
use App\Models\Paysystem;
use Illuminate\Database\Eloquent\Factories\Factory;

class DirectionFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Direction::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'fromPaysystem_id' => Paysystem::factory()->create(),
            'toPaysystem_id' => Paysystem::factory()->create(),
            'base_rate' => $this->faker->randomFloat(),
            'tariff' => $this->faker->randomFloat(),
            'total_rate' => $this->faker->randomFloat(),
        ];
    }
}
