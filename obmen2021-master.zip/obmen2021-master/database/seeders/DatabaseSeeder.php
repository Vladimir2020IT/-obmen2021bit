<?php

namespace Database\Seeders;

use App\Models\Paysystem;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        DB::transaction(function () {
            DB::table('currencies')->insert([
                    ['id' => 'BTC', 'precision' => 8, 'pos' => 1],
                    ['id' => 'ETH', 'precision' => 8, 'pos' => 2],
                    ['id' => 'BCH', 'precision' => 8, 'pos' => 3],
                    ['id' => 'BSV', 'precision' => 8, 'pos' => 4],
                    ['id' => 'XMR', 'precision' => 8, 'pos' => 5],
                    ['id' => 'DASH', 'precision' => 8, 'pos' => 6],
                    ['id' => 'LTC', 'precision' => 8, 'pos' => 7],
                    ['id' => 'ZEC', 'precision' => 8, 'pos' => 8],
                    ['id' => 'BNB', 'precision' => 8, 'pos' => 9],
                    ['id' => 'EOS', 'precision' => 4, 'pos' => 10],
                    ['id' => 'XRP', 'precision' => 4, 'pos' => 11],
                    ['id' => 'XLM', 'precision' => 8, 'pos' => 12],
                    ['id' => 'TRX', 'precision' => 8, 'pos' => 13],
                    ['id' => 'USDT', 'precision' => 2, 'pos' => 14],
                ]
            );

            DB::table('paysystems')->insert([
                ['category_id' => Paysystem::CRYPTO, 'currency_id' => 'BTC', 'class' => 'Bitcoin', 'name' => 'BTC'],
                ['category_id' => Paysystem::TOKEN, 'currency_id' => 'ETH', 'class' => 'Ethereum', 'name' => 'ETH'],
                ['category_id' => Paysystem::CRYPTO, 'currency_id' => 'BCH', 'class' => 'BitcoinCash', 'name' => 'BCH'],
                ['category_id' => Paysystem::CRYPTO, 'currency_id' => 'BSV', 'class' => 'BitcoinSV', 'name' => 'BSV'],
                ['category_id' => Paysystem::CRYPTO, 'currency_id' => 'XMR', 'class' => 'Monero', 'name' => 'XMR'],
                ['category_id' => Paysystem::CRYPTO, 'currency_id' => 'DASH', 'class' => 'DASH', 'name' => 'DASH'],
                ['category_id' => Paysystem::CRYPTO, 'currency_id' => 'LTC', 'class' => 'Litecoin', 'name' => 'LTC'],
                ['category_id' => Paysystem::CRYPTO, 'currency_id' => 'ZEC', 'class' => 'ZCash', 'name' => 'ZEC'],
                ['category_id' => Paysystem::TOKEN, 'currency_id' => 'BNB', 'class' => 'BNB', 'name' => 'BNB'],
                ['category_id' => Paysystem::TOKEN, 'currency_id' => 'EOS', 'class' => 'EOS', 'name' => 'EOS'],
                ['category_id' => Paysystem::TOKEN, 'currency_id' => 'XRP', 'class' => 'Ripple', 'name' => 'XRP'],
                ['category_id' => Paysystem::TOKEN, 'currency_id' => 'XLM', 'class' => 'Stellar', 'name' => 'XLM'],
                ['category_id' => Paysystem::TOKEN, 'currency_id' => 'TRX', 'class' => 'TRX', 'name' => 'TRX'],
                ['category_id' => Paysystem::STABLECOIN, 'currency_id' => 'USDT', 'class' => 'USDTERC20', 'name' => 'USDT ERC-20'],
                ['category_id' => Paysystem::STABLECOIN, 'currency_id' => 'USDT', 'class' => 'USDTTRC20', 'name' => 'USDT TRC-20'],
            ]);

            $usdterc20 = Paysystem::whereClass('USDTERC20')->first();
            $usdttrc20 = Paysystem::whereClass('USDTTRC20')->first();
            $ids = [$usdterc20->id, $usdttrc20->id];
            $tariff = 3;

            foreach (Paysystem::whereNotIn('id', $ids)->get() as $paysystem) {
                foreach ($ids as $id) {
                    DB::table('directions')->insert([
                        ['fromPaysystem_id' => $id, 'toPaysystem_id' => $paysystem->id, 'tariff' => $tariff],
                        ['fromPaysystem_id' => $paysystem->id, 'toPaysystem_id' => $id, 'tariff' => $tariff],
                    ]);
                }
            }
        });
    }
}
