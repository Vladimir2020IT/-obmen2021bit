<?php

namespace App\Http\Controllers;

use App\Models\Param;
use App\Models\Tools;
use Schema;

class ParamController extends Controller
{
    public function index()
    {
        $fields = request()->only(Schema::getColumnListing('params'));
        return Tools::queryFilter(Param::query(), $fields);
    }

    public function update()
    {
        $attributes = request()->validate([
            'value' => ['nullable'],
        ]);

        $param = Param::whereId(request('id'));
        $param->update($attributes);
        return $param->first();
    }
}
