<?php

namespace App\Http\Controllers;

use App\Models\Direction;
use App\Models\Tools;
use Illuminate\Http\Request;
use Schema;

class DirectionController extends Controller
{
    public function index(Request $request)
    {
        $fields = $request->only(array_merge(Schema::getColumnListing('directions'), ['fromPaysystem_name', 'toPaysystem_name']));
        $query = Direction::getAdminQuery();
        Tools::renameArrayKeys($fields, [
            'id' => 'directions.id',
            'fromPaysystem_name' => 'ps1.name',
            'toPaysystem_name' => 'ps2.name',
        ]);
        return Tools::queryFilter($query, $fields);
    }

    public function update()
    {
        $attributes = request()->validate([
            'tariff' => ['required', 'numeric', 'min:-20', 'max:20'],
            'is_active' => ['required', 'string', 'in:true,false'],
        ]);
        $attributes['is_active'] = $attributes['is_active'] === "true";

        $direction = Direction::whereId(request('id'))->first();
        $direction->update($attributes);

        $request = new Request();
        return $this->index($request->replace(['id' => $direction->id]))->first();
    }
}
