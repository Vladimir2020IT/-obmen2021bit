<?php

namespace App\Http\Controllers;

use App\Models\Paysystem;
use App\Models\Tools;
use Schema;

class PaysystemController extends Controller
{
    public function index()
    {
        $fields = request()->only(Schema::getColumnListing('paysystems'));
        return Tools::queryFilter(Paysystem::query(), $fields);
    }

    public function update()
    {
        $attributes = request()->validate([
            'category_id' => ['nullable', 'numeric', 'in:10,20,30'],
            'minimum' => ['required', 'numeric', 'min:0'],
            'maximum' => ['nullable', 'numeric', 'min:0'],
            'is_active' => ['required', 'string', 'in:true,false'],
            'pos' => ['required', 'integer', 'between:0,255'],
        ]);
        $attributes['is_active'] = $attributes['is_active'] === "true";

        $paysystem = Paysystem::whereId(request('id'));
        $paysystem->update($attributes);
        return $paysystem->first();
    }
}
