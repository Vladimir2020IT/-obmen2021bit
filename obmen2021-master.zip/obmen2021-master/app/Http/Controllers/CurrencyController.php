<?php

namespace App\Http\Controllers;

use App\Models\Currency;
use App\Models\Tools;
use Schema;

class CurrencyController extends Controller
{
    public function index()
    {
        $fields = request()->only(Schema::getColumnListing('currencies'));
        return Tools::queryFilter(Currency::query(), $fields);
    }

    public function update()
    {
        $attributes = request()->validate([
            'pos' => ['required', 'integer', 'between:0,255'],
        ]);

        $currency = Currency::whereId(request('id'));
        $currency->update($attributes);
        return $currency->first();
    }
}
