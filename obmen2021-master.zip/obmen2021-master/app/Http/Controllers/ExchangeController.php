<?php

namespace App\Http\Controllers;

use App\Models\Exchange;
use App\Models\Tools;
use Schema;

class ExchangeController extends Controller
{
    public function index()
    {
        $fields = request()->only(array_merge(Schema::getColumnListing('exchanges'), ['user_name', 'referrer_name', 'direction_name']));
        $query = Exchange::getAdminQuery();
        Tools::renameArrayKeys($fields, [
            'id' => 'exchanges.id',
            'user_name' => 'u1.name',
            'referrer_name' =>  'u2.name',
            'fromPaysystem_name' => 'ps1.name',
            'toPaysystem_name' => 'ps2.name',
        ]);
        return Tools::queryFilter($query, $fields);
    }
}
