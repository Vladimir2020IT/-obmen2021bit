<?php

namespace App\Http\Controllers;

use App\Models\Direction;
use App\Models\Exchange;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\MessageBag;

class WelcomeController extends Controller
{
    public function index()
    {
        return view('welcome', [
            'fields' => $this->fields(Direction::whereId(2)->first()),
        ]);
    }

    public function exchangeView()
    {
        return view('exchangeView');
    }

    /**
     * @param Direction $direction
     * @return array
     */

    public function fields(Direction $direction): array
    {
        return $direction->getFields();
    }

    public function rates(): array
    {
        return Direction::getRatesJSON();
    }

    public function exchange(Direction $direction): array
    {
        $field_names = array_keys($direction->getFields()["rules"]);
        $exchange = Exchange::new($direction, request('from_amount', 0), request('to_amount', 0), request()->only($field_names));

        if ($exchange instanceof Exchange) {
            return ['status' => 'success', 'exchange' => $exchange];
        } else {
            return ['status' => 'error', 'errors' => $exchange instanceof MessageBag ? $exchange->messages() : ['unknown' => ['Непредвиненная ошибка.']]];
        }
    }

    public function getExchange(Exchange $exchange, string $hash): array
    {
        if ($exchange->hash !== $hash) {
            abort(403);
        }

        $data = $exchange->toArray();
        $data['status_name'] = $exchange->status_name;
        $data['from_name'] = $exchange->direction->fromPaysystem->name;
        $data['to_name'] = $exchange->direction->toPaysystem->name;

        return $data;
    }
}
