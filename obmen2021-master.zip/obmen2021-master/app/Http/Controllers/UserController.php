<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Tools;
use Schema;

class UserController extends Controller
{
    public function index()
    {
        $fields = request()->only(Schema::getColumnListing('users'));
        return Tools::queryFilter(User::query(), $fields);
    }

    public function update()
    {
        $attributes = request()->validate([
            'role_id' => ['nullable', 'numeric', 'in:10,20,30'],
        ]);

        $user = User::whereId(request('id'));
        $user->update($attributes);
        return $user->first();
    }
}
