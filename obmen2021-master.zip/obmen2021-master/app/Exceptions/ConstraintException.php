<?php

namespace App\Exceptions;

use Exception;

class ConstraintException extends Exception
{
    //
}
