<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Param
 *
 * @method static \Illuminate\Database\Eloquent\Builder|Param newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Param newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Param query()
 * @mixin \Eloquent
 * @property int $id
 * @property string $name
 * @property string $value
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|Param whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Param whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Param whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Param whereUpdatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Param whereValue($value)
 * @property int $visible
 * @method static \Illuminate\Database\Eloquent\Builder|Param whereVisible($value)
 */
class Param extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'value'];

    public static function getValue($name)
    {
        return static::firstOrCreate(
            ['name' => $name],
        )->value;
    }

    public static function setValue($name, $value)
    {
        $param = static::firstOrCreate(
            ['name' => $name],
        );
        $param->value = $value;
        $param->update();
    }
}
