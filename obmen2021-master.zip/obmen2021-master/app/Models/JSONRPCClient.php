<?php

namespace App\Models;

/**
 * @method validateaddress($address)
 * @method getbalance(string $address = '', int $minConf = 1)
 * @method getnewaddress(string $label = '')
 * @method sendtoaddress($cryptoAddress, float $amount, string $comment)
 * @method listsinceblock(string $block_hash, int $confirmations)
 * @method eth_getBalance(string $address, string $block)
 * @method personal_newAccount(string $password)
 * @method eth_call(array $object, string $block)
 * @method personal_unlockAccount(string $address, string $password, int $unlockDuration)
 * @method eth_getTransactionCount(string $address, string $block)
 * @method eth_gasPrice()
 * @method eth_estimateGas(array $object)
 * @method eth_signTransaction(array $object)
 * @method eth_sendRawTransaction(string $raw_transaction)
 * @method validate_address($address)
 * @method create_address(array $params)
 * @method transfer(array $params)
 * @method get_transfers(array $params)
 */
class JSONRPCClient
{
    private $url;
    private $id;
    private $transformArray;
    private $debug;

    public function __construct($url, $transformArray = false, $debug = false)
    {
        $this->url = $url;
        $this->id = mt_rand(1, 10000);
        $this->transformArray = $transformArray;
        $this->debug = $debug;
    }

    public function __call($method, $params)
    {
        $request = [
            'jsonrpc' => '2.0',
            'method' => $method,
            'id' => $this->id,
        ];

        if ($this->transformArray && count($params) == 1 && is_array($params[0])) {
            $request['params'] = $params[0];
        } else {
            $request['params'] = $params;
        }

        $request = json_encode($request);

        $opts = ['http' => [
            'method' => 'POST',
            'header' => 'Content-type: application/json',
            'content' => $request,
            'ignore_errors' => $this->debug,
        ]];
        $context = stream_context_create($opts);
        if ($fp = @fopen($this->url, 'r', false, $context)) {
            $response = '';
            while ($row = fgets($fp)) {
                $response .= trim($row) . "\n";
            }
            $response = json_decode($response, true);
        } else {
            Tools::sendLogMessage("Не получается открыть URL:\r\n\r\n{$this->url}\r\n\r\n{$method}: " . print_r($params, true));
            return false;
        }

        if (!isset($response['id']) || $response['id'] != $this->id) {
            Tools::sendLogMessage("Ошибка в ответе URL:\r\n\r\n{$this->url}\r\n\r\n{$method}: " . print_r($params, true));
            return false;
        }

        if (isset($response['error']) && !is_null($response['error'])) {
            Tools::sendLogMessage("Ошибка в ответе URL:\r\n\r\n{$this->url}\r\n\r\n{$response['error']}\r\n\r\n{$method}: " . print_r($params, true));

            if ($this->debug) {
                var_dump($response);
            }

            return false;
        }

        return $response['result'];
    }
}
