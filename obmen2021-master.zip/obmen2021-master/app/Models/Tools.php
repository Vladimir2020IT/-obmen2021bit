<?php

namespace App\Models;

use Telegram;
use Illuminate\Database\Eloquent\Builder;

class Tools
{
    const proowoo_telegram_chat_id = '-475960112';

    public static function sendLogMessage($text)
    {
        Telegram::sendMessage([
            'chat_id' => static::proowoo_telegram_chat_id,
            'text' => $text,
        ]);
    }

    public static function floor($value, $precision)
    {
        return floor($value * pow(10, $precision)) / pow(10, $precision);
    }

    public static function ceil($value, $precision)
    {
        return ceil($value * pow(10, $precision)) / pow(10, $precision);
    }

    public static function queryFilter(Builder $query, array $fields)
    {
        foreach ($fields as $key => $value) {
            if ($value !== null) {
                $query->where($key, 'LIKE', "%{$value}%");
            }
        }
        return $query->get();
    }

    public static function renameArrayKey(array &$array, string $keyName, string $newKeyName)
    {
        if (isset($array[$keyName])) {
            $array[$newKeyName] = $array[$keyName];
            unset($array[$keyName]);
        }
    }

    public static function renameArrayKeys(&$array, array $keys)
    {
        foreach ($keys as $keyName => $newKeyName) {
            static::renameArrayKey($array, $keyName, $newKeyName);
        }
    }

    public static function getJsonContent($url, $name)
    {
        $json = null;
        $content = @file_get_contents($url);
        if ($content !== false) {
            $json = json_decode($content, true);
            if ($json === null) {
                static::sendLogMessage("Не удалось декодировать: $name\r\n\r\n$url");
            }
        } else {
            static::sendLogMessage("Не удалось загрузить: $name\r\n\r\n$url");
        }

        return $json;
    }
}
