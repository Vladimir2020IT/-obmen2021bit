<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\CryptoAccount
 *
 * @property int $id
 * @property string $name
 * @property string $address
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|CryptoAccount newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|CryptoAccount newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|CryptoAccount query()
 * @method static \Illuminate\Database\Eloquent\Builder|CryptoAccount whereAddress($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CryptoAccount whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CryptoAccount whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CryptoAccount whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|CryptoAccount whereUpdatedAt($value)
 * @mixin \Eloquent
 */
class CryptoAccount extends Model
{
    use HasFactory;

    public static function getNameByAddress($address)
    {
        $cryptoAccount = static::whereAddress($address)->first();
        return $cryptoAccount !== null ? $cryptoAccount->name : null;
    }
}
