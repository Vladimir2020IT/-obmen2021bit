<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\TRXAddress
 *
 * @method static \Illuminate\Database\Eloquent\Builder|TRXAddress newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|TRXAddress newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|TRXAddress query()
 * @mixin \Eloquent
 * @property int $id
 * @property string $address_base58
 * @property string $private_key
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|TRXAddress whereAddressBase58($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TRXAddress whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TRXAddress whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TRXAddress wherePrivateKey($value)
 * @method static \Illuminate\Database\Eloquent\Builder|TRXAddress whereUpdatedAt($value)
 */
class TRXAddress extends Model
{
    use HasFactory;

    protected $table = 'trx_addresses';

    public static function getPrivateKeyByAddress($address)
    {
        $trxAddress = static::whereAddressBase58($address)->first();
        return $trxAddress !== null ? $trxAddress->private_key : null;
    }
}
