<?php

namespace App\Models;

use App\Exceptions\ConstraintException;
use App\Models\Paysystems\PS;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Direction
 *
 * @property-read \App\Models\Paysystem $fromPaysystem
 * @property-read \App\Models\Paysystem $toPaysystem
 * @method static \Illuminate\Database\Eloquent\Builder|Direction newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Direction newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Direction query()
 * @mixin \Eloquent
 * @property int $id
 * @property int $fromPaysystem_id
 * @property int $toPaysystem_id
 * @property string $base_rate
 * @property string $tariff
 * @property string $total_rate
 * @property int $is_active
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|Direction whereBaseRate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Direction whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Direction whereFromPaysystemId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Direction whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Direction whereIsActive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Direction whereTariff($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Direction whereToPaysystemId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Direction whereTotalRate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Direction whereUpdatedAt($value)
 * @property-read mixed $inverse
 */
class Direction extends Model
{
    use HasFactory;

    protected $fillable = ['tariff', 'is_active'];

    public function fromPaysystem()
    {
        return $this->belongsTo(Paysystem::class, 'fromPaysystem_id');
    }

    public function toPaysystem()
    {
        return $this->belongsTo(Paysystem::class, 'toPaysystem_id');
    }

    public function getInverseAttribute()
    {
        return $this->fromPaysystem->currency->pos > $this->toPaysystem->currency->pos;
    }

    public function getFields()
    {
        $fromClass = $this->fromPaysystem->getClass();
        $toClass = $this->toPaysystem->getClass();

        return [
            'rules' => array_merge(PS::defaultFields, $fromClass->fromFields, $toClass->toFields),
            'labels' => array_merge($fromClass->labels, $toClass->labels),
            'messages' => array_merge($fromClass->customMessages, $toClass->customMessages),
        ];
    }

    protected static function booted()
    {
        static::saving(function ($direction) {
            if ($direction->fromPaysystem->is($direction->toPaysystem)) {
                throw new ConstraintException('a_fromPaysystem_is_a_toPaysystem_exception');
            }

            $direction->total_rate = $direction->fromPaysystem->currency->pos <= $direction->toPaysystem->currency->pos ?
                $direction->base_rate * (1 - $direction->tariff * 0.01) : $direction->base_rate * (1 + $direction->tariff * 0.01);
        });
    }

    public static function getRatesJSON()
    {
        $data = [];

        $directions = Direction::all();
        foreach ($directions as $direction) {
            foreach ([$direction->fromPaysystem, $direction->toPaysystem] as $paysystem) {
                if (!isset($data['categories'][$paysystem->category_id])) {
                    $data['categories'][$paysystem->category_id] = [
                        'id' => $paysystem->category_id,
                        'name' => $paysystem->category_name,
                    ];
                }

                if (!isset($data['paysystems'][$paysystem->id])) {
                    $data['paysystems'][$paysystem->id] = [
                        'id' => $paysystem->id,
                        'category_id' => $paysystem->category_id,
                        'precision' => $paysystem->currency->precision,
                        'class' => $paysystem->class,
                        'name' => $paysystem->name,
                        'total_reserve' => $paysystem->total_reserve,
                        'auto_reserve' => $paysystem->auto_reserve,
                        'min' => $paysystem->minimum,
                        'max' => $paysystem->maximum,
                        'pos' => $paysystem->pos,
                    ];
                }
            }

            $data['directions'][$direction->id] = [
                'id' => $direction->id,
                'fromPaysystem_id' => $direction->fromPaysystem_id,
                'toPaysystem_id' => $direction->toPaysystem_id,
                'base_rate' => $direction->base_rate,
                'tariff' => $direction->tariff,
                'total_rate' => $direction->total_rate,
                'inverse' => $direction->inverse,
            ];
        }

        return $data;
    }

    public static function getByClasses($from_class, $to_class)
    {
        return Direction::whereHas('fromPaysystem', function ($q) use ($from_class) {
            $q->where('class', $from_class);
        })->whereHas('toPaysystem', function ($q) use ($to_class) {
            $q->where('class', $to_class);
        })->first();
    }

    public function setActive()
    {
        $this->is_active = 1;
        $this->update();
    }

    public function setInactive()
    {
        $this->is_active = 0;
        $this->update();
    }

    public static function getAdminQuery()
    {
        return Direction::query()
            ->select(['directions.*', 'ps1.name AS fromPaysystem_name', 'ps2.name AS toPaysystem_name'])
            ->join('paysystems AS ps1', 'directions.fromPaysystem_id', '=', 'ps1.id')
            ->join('paysystems AS ps2', 'directions.toPaysystem_id', '=', 'ps2.id');
    }
}
