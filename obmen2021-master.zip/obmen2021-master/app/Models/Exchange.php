<?php

namespace App\Models;

use App\Events\StatusChanged;
use App\Exceptions\ConstraintException;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\MessageBag;

/**
 * \App\Models\Exchange
 *
 * @property int $id
 * @property int|null $user_id
 * @property int|null $nonce
 * @property int|null $referrer_id
 * @property int $status_id
 * @property int $direction_id
 * @property string $create_date
 * @property string|null $pay_date
 * @property string|null $complete_date
 * @property string $from_amount
 * @property string $to_amount
 * @property string $base_rate
 * @property string $tariff
 * @property string $total_rate
 * @property string $profit
 * @property string $referrer_profit
 * @property array|null $form
 * @property array|null $requisites
 * @property array|null $info
 * @property string $hash
 * @property-read \App\Models\Direction $direction
 * @property-read mixed $status_name
 * @property-read \App\Models\User|null $referrer
 * @property-read \App\Models\User|null $user
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange query()
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereBaseRate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereCompleteDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereCreateDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereDirectionId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereForm($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereFromAmount($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereHash($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereInfo($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereNonce($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange wherePayDate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereProfit($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereReferrerId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereReferrerProfit($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereRequisites($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereStatusId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereTariff($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereToAmount($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereTotalRate($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Exchange whereUserId($value)
 * @mixin \Eloquent
 */
class Exchange extends Model
{
    use HasFactory;

    const NEW = 10;
    const PAID = 20;
    const PROCESSING = 30;
    const COMPLETED = 40;

    protected $casts = [
        'form' => 'array',
        'requisites' => 'array',
        'info' => 'array',
    ];

    public $timestamps = false;

    public function getStatusNameAttribute()
    {
        $statusNames = [
            static::NEW => 'Не оплачена',
            static::PAID => 'Оплачена',
            static::PROCESSING => 'В обработке',
            static::COMPLETED => 'Завершена',
        ];

        return $statusNames[$this->status_id] ?? 'Неизвестный';
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function referrer()
    {
        return $this->belongsTo(User::class, 'referrer_id');
    }

    public function direction()
    {
        return $this->belongsTo(Direction::class, 'direction_id');
    }

    protected static function booted()
    {
        static::saving(function ($exchange) {
            if ($exchange->user !== null && $exchange->user->is($exchange->referrer)) {
                throw new ConstraintException('a_parent_id_is_an_id_exception');
            }

            $exchange->hash = bin2hex(random_bytes(16));
        });
    }

    protected function setToAmount()
    {
        $this->from_amount = Tools::floor($this->from_amount, $this->direction->fromPaysystem->currency->precision);
        $this->to_amount = Tools::floor($this->direction->inverse ? $this->from_amount / $this->total_rate :
            $this->from_amount * $this->total_rate, $this->direction->toPaysystem->currency->precision);
    }

    protected function setFromAmount()
    {
        $this->to_amount = Tools::floor($this->to_amount, $this->direction->toPaysystem->currency->precision);
        $this->from_amount = Tools::ceil($this->direction->inverse ? $this->to_amount * $this->total_rate :
            $this->to_amount / $this->total_rate, $this->direction->fromPaysystem->currency->precision);
    }

    protected function validate()
    {
        $messageBag = new MessageBag;

        if ($this->direction->is_active && $this->direction->total_rate > 0 &&
            $this->direction->fromPaysystem->is_active && $this->direction->toPaysystem->is_active) {
            // Направление и платежные системы должны быть активными
            if ($this->from_amount > 0) {
                // Если указана сумма к отправке
                $this->setToAmount();
            } elseif ($this->to_amount > 0) {
                // Если указана сумма к получению
                $this->setFromAmount();
            } else {
                $messageBag->add('amounts', 'Сумма обмена не указана, либо указана неверно.');
            }

            if ($messageBag->isEmpty()) {
                // Производим проверку сумм только в случае, если одна из сумм указана верно

                if ($this->from_amount < $this->direction->fromPaysystem->minimum) {
                    $messageBag->add('from_amount', 'Сумма обмена ниже минимальной.');
                }

                if ($this->to_amount < $this->direction->toPaysystem->minimum) {
                    $messageBag->add('to_amount', 'Сумма обмена ниже минимальной.');
                }

                if ($this->direction->fromPaysystem->maximum !== null && $this->from_amount > $this->direction->fromPaysystem->maximum) {
                    $messageBag->add('from_amount', 'Сумма обмена выше максимальной.');
                }

                if ($this->direction->toPaysystem->maximum !== null && $this->to_amount > $this->direction->toPaysystem->maximum) {
                    $messageBag->add('to_amount', 'Сумма обмена выше максимальной.');
                }
            }

            if ($messageBag->isEmpty()) {
                // Производим проверку формы только в случае, если прошли все предыдущие проверку

                $fields = $this->direction->getFields();

                $this->form = array_intersect_key($this->form, $fields['rules']); // Исключаем попадание лишних данных в форму
                $validator = validator($this->form, $fields['rules'], $fields['messages'], $fields['labels']);

                $messageBag = $validator->errors();
            }
        } else {
            $messageBag->add('direction_id', 'Направление не активно.');
        }

        return $messageBag;
    }

    protected function updateRates()
    {
        $this->base_rate = $this->direction->base_rate;
        $this->tariff = $this->direction->tariff;
        $this->total_rate = $this->direction->total_rate;
    }

    public static function confirmReceive(int $exchange_id, float $from_amount, array $info, string $class)
    {
        try {
            DB::beginTransaction();

            $exchange = Exchange::whereId($exchange_id)
                ->whereStatusId(Exchange::NEW)
                ->whereNull('pay_date')
                ->whereNull('complete_date')
                ->limit(1)
                ->lockForUpdate()->get()->first();

            if ($exchange !== null && $exchange->direction->fromPaysystem->class == $class) {
                $exchange->status_id = static::PAID;
                $exchange->pay_date = now();
                $exchange->from_amount = $from_amount;
                $exchange->info = array_merge($exchange->info, $info);

                $diffInMinutes = $exchange->pay_date->diffInMinutes($exchange->create_date);
                if ($diffInMinutes > 10) {
                    $exchange->updateRates();
                }
                $exchange->setToAmount();
                $exchange->update();

                DB::commit();

                event(new StatusChanged($exchange));
            } else {
                DB::rollBack();
            }
        } catch (\Throwable $e) {
            if (DB::transactionLevel() > 0) {
                DB::rollBack();
            }
        }
    }

    /**
     * @param Direction $direction
     * @param float $from_amount
     * @param float $to_amount
     * @param array $form
     * @param array $info
     * @return Exchange|MessageBag
     */

    public static function new(Direction $direction, float $from_amount, float $to_amount, array $form)
    {
        if ($direction->updated_at->addMinutes(5) < now()) {
            return new MessageBag([
                'direction_id' => 'Направление не доступно',
            ]);
        }

        $exchange = new Exchange;

        $exchange->status_id = static::NEW;
        $exchange->direction_id = $direction->id;
        $exchange->from_amount = $from_amount;
        $exchange->to_amount = $to_amount;
        $exchange->updateRates();
        $exchange->form = $form;
        $exchange->requisites = ["error" => "Не удалось сгенерировать {$direction->fromPaysystem->name} адрес."];
        $exchange->info = [];

        $messageBag = $exchange->validate();

        if ($messageBag->isEmpty()) {
            if ($exchange->save()) {
                $direction->fromPaysystem->getClass()->setRequisites($exchange);
                return $exchange;
            } else {
                $messageBag->add('', 'Не удалось создать заявку.');
            }
        }

        return $messageBag;
    }

    public function pay()
    {
        $class = $this->direction->toPaysystem->getClass();
        if ($class !== null) {
            return $class->pay($this);
        } else {
            return false;
        }
    }

    public static function getAdminQuery()
    {
        return Exchange::query()
            ->select(['exchanges.*', 'u1.name AS user_name', 'u2.name AS referrer_name', 'ps1.name AS fromPaysystem_name', 'ps2.name AS toPaysystem_name'])
            ->leftJoin('users AS u1', 'exchanges.user_id', '=', 'u1.id')
            ->leftJoin('users AS u2', 'exchanges.referrer_id', '=', 'u2.id')
            ->join('directions AS d', 'exchanges.direction_id', '=', 'd.id')
            ->join('paysystems AS ps1', 'd.fromPaysystem_id', '=', 'ps1.id')
            ->join('paysystems AS ps2', 'd.toPaysystem_id', '=', 'ps2.id');
    }
}
