<?php

namespace App\Models;

use App\Models\Paysystems\PS;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Paysystem
 *
 * @property-read mixed $category_name
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem query()
 * @mixin \Eloquent
 * @property int $id
 * @property int|null $category_id
 * @property string $currency_id
 * @property string $class
 * @property string $name
 * @property mixed|null $form
 * @property mixed|null $json
 * @property string $total_reserve
 * @property string $auto_reserve
 * @property string|null $minimum
 * @property string|null $maximum
 * @property int $is_active
 * @property int $pos
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property-read \App\Models\Currency $currency
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereAutoReserve($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereCategoryId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereClass($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereCurrencyId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereForm($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereIsActive($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereJson($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereMaximum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereMinimum($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereName($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem wherePos($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereTotalReserve($value)
 * @method static \Illuminate\Database\Eloquent\Builder|Paysystem whereUpdatedAt($value)
 */
class Paysystem extends Model
{
    use HasFactory;

    const CRYPTO = 10;
    const TOKEN = 20;
    const STABLECOIN = 30;

    protected $fillable = ['category_id', 'minimum', 'maximum', 'is_active', 'pos'];

    public function getCategoryNameAttribute()
    {
        $categoryNames = [
            static::CRYPTO => 'Криптовалюты',
            static::TOKEN => 'Токены',
            static::STABLECOIN => 'Стейблкоины',
        ];

        return $categoryNames[$this->category_id] ?? '';
    }

    public function currency()
    {
        return $this->belongsTo(Currency::class, 'currency_id');
    }

    /**
     * @return PS
     */

    public function getClass()
    {
        $className = "\\App\\Models\\Paysystems\\{$this->class}";

        return class_exists($className) ? new $className : null;
    }

    public function setActive()
    {
        $this->is_active = 1;
        $this->update();
    }

    public function setInactive()
    {
        $this->is_active = 0;
        $this->update();
    }
}
