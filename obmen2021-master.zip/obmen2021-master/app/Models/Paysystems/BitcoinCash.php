<?php

namespace App\Models\Paysystems;

class BitcoinCash extends Bitcoin
{
    const connection = 'http://bitcoincashrpc:1ed8afcec616cebedda4817aa0a8cf36@192.168.150.101:8330/';
}
