<?php

namespace App\Models\Paysystems;

use App\Models\Exchange;
use App\Models\Tools;

class EOS extends PS
{
    const nodeConnection = 'https://api.eoslaomao.com';
    const historyConnection = 'https://eos.hyperion.eosrio.io';
    const walletConnection = 'http://127.0.0.1:8888';
    const publicKey = 'EOS5aAwhyUNyp8Q2u57TggYzqtMfc1SVBhAswQee2FASv5k6p3MaE';
    const password = 'PW5JihPoFXptjDBUft6x8R84yyeoi4UHd1sPfiLxwWz135aBAQQmm';
    const chain_id = 'aca376f206b8fc25a6ed44dbdc66547c36c6c33e3a119ffbeaef943642f0e906';
    const account = 'exproowoocom';
    const token = 'eosio.token';
    const symbol = 'EOS';
    const offset = 100;

    protected function request($url, $path, $data = null, $returnJson = true)
    {
        $ch = curl_init();
        if ($data !== null) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-type: application/json']);
        curl_setopt($ch, CURLOPT_URL, $url . $path);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);

        if ($result === false) {
            Tools::sendLogMessage("Ошибка в запросе EOS: {$url}{$path}\r\n\r\n" . curl_error($ch));
            return $returnJson ? null : false;
        } elseif ($returnJson) {
            $json = json_decode($result, true);
            if ($json !== null) {
                return $json;
            } else {
                Tools::sendLogMessage("Не удалось декодировать ответ EOS: {$url}{$path}\r\n\r\n" . curl_error($ch));
            }
        } else {
            return $result;
        }
    }

    protected function transfer($to, $amount, $memo)
    {
        $bin = $this->request(static::nodeConnection, '/v1/chain/abi_json_to_bin', [
            'code' => static::token,
            'action' => 'transfer',
            'args' => [
                'from' => static::account,
                'to' => $to,
                'quantity' => number_format($amount, 4, '.', '') . ' ' . static::symbol,
                'memo' => $memo,
            ]
        ]);
        if (isset($bin['binargs'])) {
            $info = $this->request(static::nodeConnection, '/v1/chain/get_info');
            if (isset($info['head_block_num'])) {
                $block = $this->request(static::nodeConnection, '/v1/chain/get_block', ['block_num_or_id' => $info['head_block_num']]);
                if (isset($block['block_num'], $block['ref_block_prefix'])) {
                    $this->request(static::walletConnection, '/v1/wallet/unlock', ['default', static::password]);
                    $keys = $this->request(static::nodeConnection, '/v1/chain/get_required_keys', [
                        'available_keys' => [
                            static::publicKey,
                        ],
                        'transaction' => [
                            'actions' => [
                                [
                                    'account' => static::token,
                                    'name' => 'transfer',
                                    'authorization' => [
                                        [
                                            'actor' => static::account,
                                            'permission' => 'active',
                                        ],
                                    ],
                                    'data' => $bin['binargs'],
                                ],
                            ],
                            'context_free_actions' => [],
                            'context_free_data' => [],
                            'delay_sec' => 0,
                            'expiration' => date('Y-m-d\TH:i:s.v', time() + 60),
                            'max_kcpu_usage' => 0,
                            'max_net_usage_words' => 0,
                            'ref_block_num' => $block['block_num'],
                            'ref_block_prefix' => $block['ref_block_prefix'],
                            'signatures' => [],
                        ],
                    ]);
                    if (isset($keys['required_keys'][0])) {
                        $tx = $this->request(static::walletConnection, '/v1/wallet/sign_transaction', [
                            [
                                'ref_block_num' => $block['block_num'],
                                'ref_block_prefix' => $block['ref_block_prefix'],
                                'expiration' => date('Y-m-d\TH:i:s.v', time() + 60),
                                'actions' => [
                                    [
                                        'account' => static::token,
                                        'name' => 'transfer',
                                        'authorization' => [
                                            [
                                                'actor' => static::account,
                                                'permission' => 'active',
                                            ],
                                        ],
                                        'data' => $bin['binargs'],
                                    ],
                                ],
                                'signatures' => [],
                            ],
                            [
                                $keys['required_keys'][0],
                            ],
                            static::chain_id,
                        ]);
                        if (isset($tx['signatures']) && !empty($tx['signatures'])) {
                            $tx = $this->request(static::nodeConnection, '/v1/chain/push_transaction', [
                                'compression' => 'none',
                                'transaction' => $tx,
                                'signatures' => $tx['signatures'],
                            ]);
                            $this->request(static::walletConnection, '/v1/wallet/lock', 'default');
                            return $tx['transaction_id'] ?? false;
                        }
                    }
                }
            }
        }

        return false;
    }

    public function __construct()
    {
        parent::__construct();

        $this->toFields = [
            'cryptoAddress' => ['required', 'regex:/^[0-9a-z]{1,12}$/'],
            'cryptoMemo' => ['string', 'max:255'],
        ];

        $this->labels['cryptoAddress'] = "{$this->paysystem->name} адрес";
        $this->labels['cryptoMemo'] = "Memo";
    }

    public function setReserves()
    {
        $balance = false;
        $get_currency_balance = $this->request(EOS::nodeConnection, '/v1/chain/get_currency_balance', [
            'code' => static::token,
            'account' => static::account,
            'symbol' => static::symbol
        ]);
        if (!empty($get_currency_balance)) {
            $balance = explode(' ', implode($get_currency_balance));
            $balance = $balance[0];
        }
        $this->total_reserve = $this->auto_reserve = $balance;
    }

    public function setRequisites(Exchange $exchange)
    {
        $exchange->requisites = ['cryptoAddress' => static::account, 'cryptoMemo' => (string)$exchange->id];
    }

    public function receive()
    {
        if (date('i') % 2 === 0) {
            $json = Tools::getJsonContent(static::historyConnection . '/v2/history/get_actions?account=' . static::account, 'EOS Receive');
            if ($json !== null) {
                if (isset($json['actions']) && is_array($json['actions'])) {
                    foreach ($json['actions'] as $action_trace) {
                        if ($action_trace['act']['account'] == static::token && $action_trace['act']['name'] == 'transfer') {
                            list($amount, $currency) = explode(' ', $action_trace['act']['data']['quantity']);
                            $memo = $action_trace['act']['data']['memo'];
                            if ($currency == static::symbol && !empty($memo)) {
                                Exchange::confirmReceive($memo, $amount, ['txid_in' => $action_trace['trx_id'] ?? ''], $this->paysystem->class);
                            }
                        }
                    }
                } else {
                    Tools::sendLogMessage("В данных EOS Receive неправильная структура.");
                }
            }
        }
    }

    public function pay(Exchange $exchange): array
    {
        return ['txid' => $this->transfer($exchange->form['cryptoAddress'], (float)$exchange->to_amount, $exchange->form['cryptoMemo'] ?? '')];
    }
}
