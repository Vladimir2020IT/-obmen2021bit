<?php

namespace App\Models\Paysystems;

use App\Models\CryptoAccount;
use App\Models\Exchange;

class ZCash extends Bitcoin
{
    const connection = 'http://zcashrpc:f78c42a1e1321e375e26c8cae37ded78@192.168.150.101:8232/';

    public function setRequisites(Exchange $exchange)
    {
        $address = $this->rpc->getnewaddress();

        if (!empty($address)) {
            $cryptoAccount = new CryptoAccount;
            $cryptoAccount->name = (string)$exchange->id;
            $cryptoAccount->address = $address;

            if ($cryptoAccount->save()) {
                $exchange->requisites = ['cryptoAddress' => $address];
            }
        }

        $exchange->update();
    }
}
