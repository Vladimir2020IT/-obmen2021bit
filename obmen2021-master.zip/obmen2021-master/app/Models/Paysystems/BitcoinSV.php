<?php

namespace App\Models\Paysystems;

class BitcoinSV extends Bitcoin
{
    const connection = 'http://bitcoinsvrpc:5dcbdcec82da41602ae31f5e50004e87@192.168.150.101:8340/';
}
