<?php

namespace App\Models\Paysystems;

class BNB extends Ethereum
{
    const connection = 'https://bsc-dataseed.binance.org';
}
