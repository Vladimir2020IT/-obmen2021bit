<?php

namespace App\Models\Paysystems;

use App\Models\Exchange;

trait IntervalReceive
{
    protected abstract function getBalance(string $address);

    public abstract function withdraw_from_incoming_address(Exchange $exchange, float $amount = null);

    public function setReserves()
    {
        $this->total_reserve = $this->auto_reserve = $this->getBalance(static::coinbase);
    }

    public function receive()
    {
        $exchanges = Exchange::whereHas('direction', function ($query) {
            $query->where('fromPaysystem_id', '=', $this->paysystem->id);
        })
            ->where('status_id', '=', Exchange::NEW)
            ->where('create_date', '>=', 'NOW() - INTERVAL 3 DAY')
            ->get();

        foreach ($exchanges as $exchange) {
            $address = $exchange->requisites['cryptoAddress'] ?? null;

            if ($address !== null) {
                $amount = $this->getBalance($address);
                if ($amount > 0 && $amount >= $this->paysystem->minimum * 0.5) {
                    Exchange::confirmReceive($exchange->id, $amount, [], $this->paysystem->class);
                    $this->withdraw_from_incoming_address($exchange, $amount);
                }
            }
        }
    }
}
