<?php

namespace App\Models\Paysystems;

use App\Models\Exchange;
use App\Models\Tools;
use App\Models\TRXAddress;
use App\Rules\ValidTRXAddress;
use IEXBase\TronAPI\Exception\TronException;
use IEXBase\TronAPI\Provider\HttpProvider;
use IEXBase\TronAPI\Tron;
use Illuminate\Support\Facades\DB;

class TRX extends PS
{
    use IntervalReceive;

    const connection = 'https://api.trongrid.io';
    const coinbase = 'TYdw55fGEW3mdbgTqawn38cpu1DWdxE7Ns';
    const privateKey = '586a4dbd04b083c517027d49899bcb2a0229f0a6dbae8ca6c0bd5715029ff5c4';
    const unit = 1000000;
    const fee = 0;

    protected $rpc;

    public function __construct()
    {
        parent::__construct();

        $fullNode = new HttpProvider(static::connection);
        $solidityNode = new HttpProvider(static::connection);
        $eventServer = new HttpProvider(static::connection);

        try {
            $this->rpc = new Tron($fullNode, $solidityNode, $eventServer);
        } catch (\Throwable $e) {
            Tools::sendLogMessage('Произошла ошибка при инициализации RPC Tron');
            $this->rpc = false;
        }

        $this->toFields = [
            'cryptoAddress' => ['required', new ValidTRXAddress($this->rpc)],
        ];

        $this->labels['cryptoAddress'] = "{$this->paysystem->name} адрес";
    }

    protected function getPrivateKey($address)
    {
        return $address == static::coinbase ? static::privateKey : TRXAddress::getPrivateKeyByAddress($address);
    }

    protected function getBalance(string $address)
    {
        try {
            return $this->rpc->getBalance($address, true);
        } catch (\Throwable $e) {
            Tools::sendLogMessage('Произошла ошибка при получении резервов Tron');
            return false;
        }
    }

    protected function transfer(string $from, string $to, float $amount)
    {
        $this->rpc->setAddress($from);
        $this->rpc->setPrivateKey($this->getPrivateKey($from));
        try {
            $transfer = $this->rpc->send($to, $amount);
            return isset($transfer['result'], $transfer['txID']) && $transfer['result'] === true ? $transfer['txID'] : false;
        } catch (\Throwable $e) {
            Tools::sendLogMessage('Произошла ошибка при создании платежа Tron');
            return false;
        }
    }

    public function withdraw_from_incoming_address(Exchange $exchange, float $amount = null)
    {
        $this->transfer($exchange->requisites['cryptoAddress'], static::coinbase, $amount - static::fee);
    }

    public function setRequisites(Exchange $exchange)
    {
        try {
            $account = $this->rpc->createAccount();
            DB::transaction(function () use ($exchange, $account) {
                $trx_address = new TRXAddress;
                $trx_address->address_base58 = $account->getAddress(true);
                $trx_address->private_key = $account->getPrivateKey();
                if ($trx_address->save()) {
                    $exchange->requisites = ['cryptoAddress' => $trx_address->address_base58];
                }
            });
        } catch (\Throwable $e) {
            Tools::sendLogMessage('Произошла ошибка при получении реквизитов Tron');
        }

        $exchange->update();
    }

    public function pay(Exchange $exchange): array
    {
        return ['txid' => $this->transfer(static::coinbase, $exchange->form['cryptoAddress'], (float)$exchange->to_amount)];
    }
}
