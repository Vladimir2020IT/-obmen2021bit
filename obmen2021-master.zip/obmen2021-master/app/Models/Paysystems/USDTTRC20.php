<?php

namespace App\Models\Paysystems;

use App\Models\Exchange;
use App\Models\Tools;
use IEXBase\TronAPI\Exception\TronException;

class USDTTRC20 extends TRX
{
    const contract = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';
    const unit = 1000000;
    const fee = 2;

    protected function getBalance(string $address)
    {
        try {
            $response = $this->rpc->getManager()->request('wallet/triggerconstantcontract', [
                'contract_address' => $this->rpc->toHex(static::contract),
                'function_selector' => 'balanceOf(address)',
                'parameter' => str_pad($this->rpc->toHex($address), 64, '0', STR_PAD_LEFT),
                'owner_address' => $this->rpc->toHex($address),
            ]);

            if (isset($response['constant_result'][0])) {
                return bcdiv(hexdec($response['constant_result'][0]), static::unit, $this->paysystem->currency->precision);
            } else {
                Tools::sendLogMessage('Произошла ошибка при получении резервов TRC20 (1)');
                return false;
            }
        } catch (\Throwable $e) {
            Tools::sendLogMessage('Произошла ошибка при получении резервов TRC20 (2)');
            return false;
        }
    }

    protected function transfer(string $from, string $to, float $amount)
    {
        try {
            $transfer = $this->rpc->getManager()->request('wallet/triggersmartcontract', [
                'contract_address' => $this->rpc->toHex(static::contract),
                'function_selector' => 'transfer(address,uint256)',
                'parameter' => str_pad($this->rpc->toHex($to), 64, '0', STR_PAD_LEFT) .
                    str_pad(dechex(bcmul($amount, static::unit)), 64, '0', STR_PAD_LEFT),
                'fee_limit' => static::fee * TRX::unit,
                'owner_address' => $this->rpc->toHex($from),
            ]);

            if (isset($transfer['transaction'])) {
                $private_key = $this->getPrivateKey($from);
                $transfer_with_sign = $this->rpc->getManager()->request('wallet/addtransactionsign', [
                    'transaction' => $transfer['transaction'],
                    'privateKey' => $private_key,
                ]);
                $broadcast = $this->rpc->getManager()->request('wallet/broadcasttransaction', $transfer_with_sign);
                return $broadcast['txid'] ?? false;
            }
        } catch (\Throwable $e) {
            Tools::sendLogMessage('Произошла ошибка при создании платежа TRC20');
        }

        return false;
    }

    public function withdraw_from_incoming_address(Exchange $exchange, float $amount = null)
    {
        parent::transfer(static::coinbase, $exchange->requisites['cryptoAddress'], static::fee);
        $this->transfer($exchange->requisites['cryptoAddress'], static::coinbase, $amount);
    }
}
