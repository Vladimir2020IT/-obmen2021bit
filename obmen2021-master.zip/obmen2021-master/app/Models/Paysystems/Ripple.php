<?php

namespace App\Models\Paysystems;

use App\Models\Exchange;
use App\Models\Param;
use App\Models\Tools;
use FOXRP\Rippled\Client;

class Ripple extends PS
{
    const localConnection = 'http://127.0.0.1:5005';
    const remoteConnection = 'https://s1.ripple.com:51234';
    const baseurl = 'https://data.ripple.com/v2/';
    const coinbase = 'rntAUEASjjvf23JDs7P7U5XrBx2v4PakB9';
    const privateKey = 'shSpMYaNLnKPfFQfTDN2q7L4Z2G8q';
    const unit = 1000000;

    protected $local_rpc;
    protected $remote_rpc;

    public function __construct()
    {
        parent::__construct();

        try {
            $this->local_rpc = new Client(static::localConnection);
            $this->remote_rpc = new Client(static::remoteConnection);
        } catch (\Throwable $e) {
            Tools::sendLogMessage('Произошла ошибка при инициализации RPC Ripple');
        }

        $this->toFields = [
            'cryptoAddress' => ['required', 'regex:/^r[0-9a-zA-Z]{24,34}$/'],
            'cryptoMemo' => ['integer', 'min:0', 'max:4294967295'],
        ];

        $this->labels['cryptoAddress'] = "{$this->paysystem->name} адрес";
        $this->labels['cryptoMemo'] = "Tag";
    }

    public function setReserves()
    {
        $balance = false;

        try {
            $response = $this->remote_rpc->send('account_info', ['account' => static::coinbase]);
            $json = json_decode($response->getRaw(), true);

            if ($json !== null && isset($json['result']['account_data']['Balance'])) {
                $balance = bcdiv($json['result']['account_data']['Balance'], static::unit, $this->paysystem->currency->precision);
            }
        } catch (\Throwable $e) {
            Tools::sendLogMessage('Произошла ошибка при получении резервов Ripple');
        }

        $this->total_reserve = $this->auto_reserve = $balance;
    }

    public function setRequisites(Exchange $exchange)
    {
        $exchange->requisites = ['cryptoAddress' => static::coinbase, 'cryptoMemo' => (string)$exchange->id];
    }

    public function receive()
    {
        $json = Tools::getJsonContent(static::baseurl . 'accounts/' . static::coinbase .
            '/transactions?start=' . (time() - 3600) . '&type=Payment&result=tesSUCCESS&descending=true&limit=100', 'Ripple Receive');
        if ($json !== null) {
            if (isset($json['transactions']) && is_array($json['transactions'])) {
                foreach ($json['transactions'] as $tx) {
                    $amount = bcdiv($tx['meta']['delivered_amount'] ?? 0, static::unit, $this->paysystem->currency->precision);
                    $memo = $tx['tx']['DestinationTag'] ?? '';

                    if (isset($tx['tx']['Amount']) && is_numeric($tx['tx']['Amount']) &&
                        (!isset($tx['tx']['SendMax']) || is_numeric($tx['tx']['SendMax'])) &&
                        (!isset($tx['tx']['DeliverMin']) || is_numeric($tx['tx']['DeliverMin'])) && !empty($memo)) {
                        Exchange::confirmReceive($memo, $amount, ['txid_in' => $tx['hash'] ?? ''], $this->paysystem->class);
                    }
                }
            } else {
                Tools::sendLogMessage("В данных Ripple Receive неправильная структура.");
            }
        }
    }

    public function pay(Exchange $exchange): array
    {
        return ['txid' => $this->transfer($exchange->form['cryptoAddress'], (float)$exchange->to_amount, $exchange->form['cryptoMemo'] ?? '')];
    }

    protected function transfer($to, $amount, $tag)
    {
        try {
            $response = $this->remote_rpc->send('server_state', ['void' => true]);
            $json = json_decode($response->getRaw(), true);

            if (isset($json['result']['state']['validated_ledger']['base_fee'])) {
                $tx_json = [
                    'Account' => static::coinbase,
                    'TransactionType' => 'Payment',
                    'Amount' => bcmul($amount, static::unit),
                    'Destination' => $to,
                    'DestinationTag' => $tag,
                    'Sequence' => Param::getValue('XRP_SEQUENCE'),
                    'Fee' => $json['result']['state']['validated_ledger']['base_fee'],
                ];

                $response = $this->local_rpc->send('sign', [
                    'tx_json' => $tx_json,
                    'secret' => static::privateKey,
                    'key_type' => 'secp256k1',
                    'offline' => true,
                ]);
                $json = json_decode($response->getRaw(), true);
                if (isset($json['result']['tx_blob'])) {
                    $response = $this->remote_rpc->send('submit', [
                        'tx_blob' => $json['result']['tx_blob'],
                    ]);
                    $json = json_decode($response->getRaw(), true);

                    if (isset($json['result']['tx_json']['hash'])) {
                        $sequence = Param::getValue('XRP_SEQUENCE');
                        Param::setValue('XRP_SEQUENCE', $sequence + 1);
                        return $json['result']['tx_json']['hash'];
                    }
                }
            }
        } catch (\Throwable $e) {
            Tools::sendLogMessage('Произошла ошибка при отправке платежа Ripple');
        }

        return false;
    }
}
