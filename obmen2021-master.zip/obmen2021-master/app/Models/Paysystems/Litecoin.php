<?php

namespace App\Models\Paysystems;

class Litecoin extends Bitcoin
{
    const connection = 'http://litecoinrpc:509ca5b3ee522c6353c200276a6472e3@192.168.150.101:9332/';
}
