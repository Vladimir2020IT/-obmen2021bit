<?php

namespace App\Models\Paysystems;

use App\Models\CryptoAccount;
use App\Models\Exchange;
use App\Models\JSONRPCClient;
use App\Models\Param;
use App\Rules\ValidMoneroAddress;

class Monero extends PS
{
    const connection = 'http://192.168.150.101:28083/json_rpc';
    const unit = 1000000000000;
    const confirmations = 10;

    protected $rpc;

    public function __construct()
    {
        parent::__construct();

        $this->rpc = new JSONRPCClient(static::connection, true);

        $this->toFields = [
            'cryptoAddress' => ['required', new ValidMoneroAddress($this->rpc)],
            'cryptoMemo' => ['regex:/^[0-9a-h]{64}$/'],
        ];

        $this->labels['cryptoAddress'] = "{$this->paysystem->name} адрес";
        $this->labels['cryptoMemo'] = "Payment ID";
    }

    public function setReserves()
    {
        $result = $this->rpc->getbalance();

        $this->total_reserve = isset($result['balance']) ? bcdiv($result['balance'], static::unit, 8) : false;
        $this->auto_reserve = isset($result['unlocked_balance']) ? bcdiv($result['unlocked_balance'], static::unit, 8) : false;
    }

    public function setRequisites(Exchange $exchange)
    {
        $address = $this->rpc->create_address(['account_index' => 0]);

        if (isset($address['address'])) {
            $cryptoAccount = new CryptoAccount;
            $cryptoAccount->name = (string)$exchange->id;
            $cryptoAccount->address = $address;

            if ($cryptoAccount->save()) {
                $exchange->requisites = ['cryptoAddress' => $address['address']];
            }
        }

        $exchange->update();
    }

    public function receive()
    {
        $height = (int)Param::getValue('MONERO_HEIGHT');
        $transfers = $this->rpc->get_transfers(['in' => true, 'filter_by_height' => true, 'min_height' => $height]);
        if (isset($transfers['in']) && is_array($transfers['in'])) {
            foreach ($transfers['in'] as $transfer) {
                $transfer_amount = bcdiv($transfer['amount'], static::unit, 8);
                if ($transfer['double_spend_seen'] == false && $transfer['unlock_time'] == 0 && $transfer['confirmations'] >= static::confirmations) {
                    $height = max($height, $transfer['height']);
                    $transfer_account = CryptoAccount::getNameByAddress($transfer['address']);
                    if ($transfer_account !== null) {
                        Exchange::confirmReceive($transfer_account, $transfer_amount, ['txid_in' => $transfer['txid']], $this->paysystem->class);
                    }
                }
            }
        }
        Param::setValue('MONERO_HEIGHT', $height);
    }

    public function pay(Exchange $exchange): array
    {
        $params = [
            'destinations' => [
                ['amount' => bcmul($exchange->to_amount, static::unit), 'address' => $exchange->form['cryptoAddress']],
            ],
            'get_tx_key' => true,
        ];
        if (!empty($exchange->form['cryptoMemo'])) {
            $params['payment_id'] = $exchange->form['cryptoMemo'];
        }
        $transfer = $this->rpc->transfer($params);
        if (isset($transfer['tx_hash'], $transfer['tx_key'])) {
            return ['txid' => $transfer['tx_hash'], 'tx_key' => $transfer['tx_key']];
        } else {
            return ['txid' => false];
        }
    }
}
