<?php

namespace App\Models\Paysystems;

use App\Models\Exchange;
use App\Models\Param;
use App\Models\Tools;
use ZuluCrypto\StellarSdk\Server;
use ZuluCrypto\StellarSdk\XdrModel\Memo;

class Stellar extends PS
{
    const publicKey = 'GBDYMCT4PWQCOB7IWVAVWXOSHDME7M6ZDY7AQYQRRP4WCE7Y3VRL2IMD';
    const privateKey = 'SBUBCVRN3QTFE4PLMMAZSQOQFQYKL3SQVTKGH3G4JR5OSZVRKH7QBAXG';

    protected $rpc;

    public function __construct()
    {
        parent::__construct();

        $this->rpc = Server::publicNet();

        $this->toFields = [
            'cryptoAddress' => ['required', 'regex:/^G[0-9A-Z]{55}$/'],
            'cryptoMemo' => ['regex:/^[0-9a-zA-Z]{28}$/'],
        ];

        $this->labels['cryptoAddress'] = "{$this->paysystem->name} адрес";
        $this->labels['cryptoMemo'] = "Memo";
    }

    public function setReserves()
    {
        try {
            $account = $this->rpc->getAccount(static::publicKey);
            $balance = $account->getNativeBalance();
        } catch (\Throwable $e) {
            Tools::sendLogMessage('Не удалось загрузить резервы Stellar');
            $balance = false;
        }

        $this->total_reserve = $this->auto_reserve = $balance;
    }

    public function setRequisites(Exchange $exchange)
    {
        $exchange->requisites = ['cryptoAddress' => static::publicKey, 'cryptoMemo' => (string)$exchange->id];
    }

    public function receive()
    {
        try {
            $account = $this->rpc->getAccount(static::publicKey);
            $token = Param::getValue('XLM_TOKEN');
            $transactions = $account->getTransactions($token);
            foreach ($transactions as $transaction) {
                $transaction_raw_data = $transaction->getRawData();
                $token = $transaction_raw_data['paging_token'];
                if ($transaction->getMemoType() != 'text' || $transaction_raw_data['successful'] !== true) {
                    continue;
                }
                $payments = $transaction->getPayments();
                foreach ($payments as $payment) {
                    $payment_raw_data = $payment->getRawData();
                    if ($payment_raw_data['type'] == 'payment' && $payment_raw_data['type_i'] == 1 &&
                        $payment_raw_data['asset_type'] == 'native' && $payment_raw_data['to'] == Stellar::publicKey) {
                        Exchange::confirmReceive($transaction->getMemo(), $payment_raw_data['amount'],
                            ['txid_in' => $payment->getId()], $this->paysystem->class);
                    }
                }
            }
            Param::setValue('XLM_TOKEN', $token);
        } catch (\Throwable $e) {
            Tools::sendLogMessage('Произошла ошибка при получении платежей Stellar');
        }
    }

    public function pay(Exchange $exchange): array
    {
        return ['txid' => $this->transfer($exchange->form['cryptoAddress'], (float)$exchange->to_amount, $exchange->form['cryptoMemo'] ?? '')];
    }

    protected function transfer($to, $amount, $tag)
    {
        try {
            $transaction = $this->rpc->buildTransaction(static::publicKey)
                ->setMemo(new Memo(Memo::MEMO_TYPE_TEXT, $tag));
            $transaction = $this->rpc->accountExists($to) ? $transaction->addLumenPayment($to, $amount) :
                $transaction->addCreateAccountOp($to, $amount);
            $response = $transaction->submit(static::privateKey);

            return $response->getRawData()['hash'] ?? false;
        } catch (\Throwable $e) {
            Tools::sendLogMessage('Произошла ошибка при отправке платежа Stellar');
            return false;
        }
    }
}
