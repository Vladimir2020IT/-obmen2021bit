<?php

namespace App\Models\Paysystems;

class DASH extends Bitcoin
{
    const connection = 'http://dashrpc:1a74ce0bd4ccac0ee622c29964a1ba7d@192.168.150.101:9998/';
}
