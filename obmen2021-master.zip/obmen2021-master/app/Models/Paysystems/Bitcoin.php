<?php

namespace App\Models\Paysystems;

use App\Models\CryptoAccount;
use App\Models\Exchange;
use App\Models\JSONRPCClient;
use App\Models\Param;
use App\Rules\ValidCryptoAddress;

class Bitcoin extends PS
{
    const connection = 'http://bitcoinrpc:c6772a2f80679e6cafca6cc13b281531@192.168.150.101:8332/';
    const confirmations = 1;

    protected $rpc;

    public function __construct()
    {
        parent::__construct();

        $this->rpc = new JSONRPCClient(static::connection);

        $this->toFields = [
            'cryptoAddress' => ['required', new ValidCryptoAddress($this->rpc)],
        ];

        $this->labels['cryptoAddress'] = "{$this->paysystem->name} адрес";
    }

    public function setReserves()
    {
        $this->total_reserve = $this->rpc->getbalance('*', 0);
        $this->auto_reserve = $this->rpc->getbalance('*', 1);
    }

    public function setRequisites(Exchange $exchange)
    {
        $address = $this->rpc->getnewaddress((string)$exchange->id);

        if (!empty($address)) {
            $exchange->requisites = ['cryptoAddress' => $address];
        }

        $exchange->update();
    }

    public function receive()
    {
        $lastBlockName = "{$this->paysystem->currency->id}_LASTBLOCK";
        $listSinceBlock = $this->rpc->listsinceblock(Param::getValue($lastBlockName), static::confirmations + 1);

        if ($listSinceBlock !== false && isset($listSinceBlock['transactions'], $listSinceBlock['lastblock']) && is_array($listSinceBlock['transactions'])) {
            foreach ($listSinceBlock['transactions'] as $tx) {
                if (isset($tx['category'], $tx['confirmations'], $tx['txid'], $tx['amount']) &&
                    $tx['category'] == 'receive' && $tx['confirmations'] >= static::confirmations) {
                    $tx_account = $tx['label'] ?? $tx['account'] ?? (isset($tx['address']) ? CryptoAccount::getNameByAddress($tx['address']) : null);
                    if ($tx_account !== null) {
                        $tx_amount = number_format($tx['amount'], 8, '.', '');
                        Exchange::confirmReceive($tx_account, $tx_amount, ['txid_in' => $tx['txid']], $this->paysystem->class);
                    }
                }
            }

            Param::setValue($lastBlockName, $listSinceBlock['lastblock']);
        }
    }

    /**
     * @param Exchange $exchange
     * @return array
     */

    public function pay(Exchange $exchange): array
    {
        return ['txid' => $this->rpc->sendtoaddress($exchange->form['cryptoAddress'], (float)$exchange->to_amount, (string)$exchange->id)];
    }
}
