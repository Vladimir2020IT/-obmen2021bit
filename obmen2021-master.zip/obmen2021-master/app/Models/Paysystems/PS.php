<?php

namespace App\Models\Paysystems;

use App\Models\Exchange;
use App\Models\Paysystem;
use ReflectionClass;

abstract class PS
{
    const defaultFields = [
        'lastName' => ['required', 'max:255'],
        'firstName' => ['required', 'max:255'],
        'email' => ['required', 'email'],
        'phone' => ['required', 'regex:/^\+[0-9]+$/'],
    ];
    public $fromFields = [];
    public $toFields = [];

    public $labels = [
        'lastName' => 'Фамилия',
        'firstName' => 'Имя',
        'email' => 'E-Mail',
        'phone' => 'Телефон (начиная с +)',
    ];

    public $customMessages = [
        'required' => 'Поле ":attribute" является обязательным',
        'min' => 'Поле ":attribute" может быть не менее ":min"',
        'max' => 'Поле ":attribute" может быть не более ":max"',
        'email' => 'Адрес электронной почты в поле ":attribute" указан неверно',
        'regex' => 'Поле ":attribute" указано неверно',
        'integer' => 'Поле ":attribute" может быть только целым числом',
    ];

    public $total_reserve;
    public $auto_reserve;

    public $paysystem;

    public abstract function setReserves();

    public abstract function setRequisites(Exchange $exchange);

    public abstract function receive();

    public abstract function pay(Exchange $exchange): array;

    public function __construct()
    {
        $reflect = new ReflectionClass($this);
        $this->paysystem = Paysystem::whereClass($reflect->getShortName())->first();
    }
}
