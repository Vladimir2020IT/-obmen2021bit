<?php

namespace App\Models\Paysystems;

use App\Models\Exchange;

class USDTERC20 extends Ethereum
{
    const contract = '0xdac17f958d2ee523a2206206994597c13d831ec7';
    const balanceOfBytes = '0x70a08231'; // first 4 bytes of Keccak-256 "balanceOf(address)" string hash
    const transferBytes = '0xa9059cbb'; // first 4 bytes of Keccak-256 "transfer(address,uint256)" string hash
    const unit = 1000000;

    public function withdraw_from_incoming_address(Exchange $exchange, float $amount = null)
    {
        $fee = $this->transfer($exchange->requisites['cryptoAddress'], (string)$exchange->id, static::contract, 0,
            $this->encodedTransferData(static::coinbase, $amount ?? $exchange->from_amount), static::FEE_MODE_ESTIMATE);
        if ($fee !== false) {
            $eth_transfer = $this->transfer(static::coinbase, '', $exchange->requisites['cryptoAddress'], $fee);
            if ($eth_transfer !== false) {
                $this->transfer($exchange->requisites['cryptoAddress'], (string)$exchange->id, static::contract, 0,
                    $this->encodedTransferData(static::coinbase, $amount ?? $exchange->from_amount));
            }
        }
    }

    protected function getBalance(string $address)
    {
        $balance = $this->remote_rpc->eth_call([
            'to' => static::contract,
            'data' => static::balanceOfBytes . $this->encodedAddress($address),
        ], 'latest');

        if ($balance !== false) {
            $balance = $this->hexdec($balance);
        }

        return $balance;
    }

    public function pay(Exchange $exchange): array
    {
        return ['txid' => $this->transfer(static::coinbase, '', static::contract, 0,
            $this->encodedTransferData($exchange->form['cryptoAddress'], $exchange->to_amount))];
    }

    protected function encodedAddress(string $address): string
    {
        if (mb_substr($address, 0, 2) == '0x') {
            $address = mb_substr($address, 2);
        }
        return str_pad($address, 64, '0', STR_PAD_LEFT);
    }

    protected function encodedAmount(float $amount): string
    {
        return str_pad($this->dechex(bcmul($amount, static::unit)), 64, '0', STR_PAD_LEFT);
    }

    protected function encodedTransferData(string $address, float $amount): string
    {
        return static::transferBytes . $this->encodedAddress($address) . $this->encodedAmount($amount);
    }
}
