<?php

namespace App\Models\Paysystems;

use App\Models\Exchange;
use App\Models\JSONRPCClient;

class Ethereum extends PS
{
    use IntervalReceive;

    const localConnection = 'http://192.168.150.101:8545';
    const remoteConnection = 'https://eth-mainnet.alchemyapi.io/v2/3I65a0o9FXlAMPmwHch10LIEydAFYgnt';
    const coinbase = '0x2fd130205b954161db4858112d020f0f338fc3d3';
    const unit = 1000000000000000000;

    const FEE_MODE_NONE = 0;
    const FEE_MODE_SUBSTRACT = 1;
    const FEE_MODE_ESTIMATE = 2;

    protected $dec = '0123456789';
    protected $hex = '0123456789ABCDEF';

    protected $local_rpc;
    protected $remote_rpc;

    public function __construct()
    {
        parent::__construct();

        $this->local_rpc = new JSONRPCClient(static::localConnection);
        $this->remote_rpc = new JSONRPCClient(static::remoteConnection);

        $this->toFields = [
            'cryptoAddress' => ['required', 'regex:/^0x[a-fA-F0-9]{40}$/'],
        ];

        $this->labels['cryptoAddress'] = "{$this->paysystem->name} адрес";
    }

    public function setRequisites(Exchange $exchange)
    {
        $address = $this->local_rpc->personal_newAccount((string)$exchange->id);

        if (!empty($address)) {
            $exchange->requisites = ['cryptoAddress' => $address];
        }

        $exchange->update();
    }

    public function pay(Exchange $exchange): array
    {
        return ['txid' => $this->transfer(static::coinbase, '', $exchange->form['cryptoAddress'], $exchange->to_amount)];
    }

    protected function getBalance(string $address)
    {
        $balance = $this->remote_rpc->eth_getBalance($address, 'latest');
        if ($balance !== false) {
            return bcdiv($this->hexdec($balance), static::unit, $this->paysystem->currency->precision);
        } else {
            return false;
        }
    }

    public function withdraw_from_incoming_address(Exchange $exchange, float $amount = null)
    {
        $this->transfer($exchange->requisites['cryptoAddress'], (string)$exchange->id, static::coinbase, $amount ?? $exchange->from_amount,
            null, static::FEE_MODE_SUBSTRACT);
    }

    protected function transfer(string $from, string $password, string $to, string $amount,
                                string $data = null, int $fee_mode = self::FEE_MODE_NONE)
    {
        if ($this->local_rpc->personal_unlockAccount($from, $password, 10) === true) {
            $nonce = $this->remote_rpc->eth_getTransactionCount($from, 'pending');
            if ($nonce !== false) {
                $gas_price = $this->remote_rpc->eth_gasPrice();
                if ($gas_price !== false) {
                    $tx_data = [
                        'nonce' => $nonce,
                        'from' => $from,
                        'to' => $to,
                        'value' => '0x' . $this->dechex(bcmul($amount, static::unit)),
                        'gasPrice' => $gas_price,
                    ];
                    if ($data !== null) {
                        $tx_data['data'];
                    }
                    $gas = $this->remote_rpc->eth_estimateGas($tx_data);
                    if ($gas !== false) {
                        if ($fee_mode !== static::FEE_MODE_NONE) {
                            $fee = bcmul($this->hexdec($gas), $this->hexdec($gas_price));
                            switch ($fee_mode) {
                                case static::FEE_MODE_ESTIMATE:
                                    return bcdiv($fee, static::unit, $this->paysystem->currency->precision);
                                case static::FEE_MODE_SUBSTRACT:
                                    $tx_data['value'] = '0x' . $this->dechex(bcsub($this->hexdec($tx_data['value']), $fee));
                                    break;
                            }
                        }
                        $tx_data['gas'] = $gas;
                        $signed_tx = $this->local_rpc->eth_signTransaction($tx_data);
                        if ($signed_tx !== false) {
                            return $this->remote_rpc->eth_sendRawTransaction($signed_tx['raw']);
                        }
                    }
                }
            }
        }

        return false;
    }

    protected function convBase($numberInput, $fromBaseInput, $toBaseInput)
    {
        if ($fromBaseInput == $toBaseInput) return $numberInput;

        $fromBase = str_split($fromBaseInput, 1);
        $toBase = str_split($toBaseInput, 1);
        $number = str_split($numberInput, 1);
        $fromLen = strlen($fromBaseInput);
        $toLen = strlen($toBaseInput);
        $numberLen = strlen($numberInput);
        $retval = '';

        if ($toBaseInput == '0123456789') {
            $retval = 0;
            for ($i = 1; $i <= $numberLen; $i++)
                $retval = bcadd($retval, bcmul(array_search($number[$i - 1], $fromBase), bcpow($fromLen, $numberLen - $i)));
            return $retval;
        }

        if ($fromBaseInput != '0123456789') {
            $base10 = static::convBase($numberInput, $fromBaseInput, '0123456789');
        } else {
            $base10 = $numberInput;
        }
        if ($base10 < strlen($toBaseInput)) {
            return $toBase[$base10];
        }

        while ($base10 != '0') {
            $retval = $toBase[bcmod($base10, $toLen)] . $retval;
            $base10 = bcdiv($base10, $toLen, 0);
        }
        return $retval;
    }

    protected function dechex($numberInput)
    {
        return $this->convBase($numberInput, $this->dec, $this->hex);
    }

    protected function hexdec($numberInput)
    {
        return $this->convBase(mb_strtoupper($numberInput), $this->hex, $this->dec);
    }
}
