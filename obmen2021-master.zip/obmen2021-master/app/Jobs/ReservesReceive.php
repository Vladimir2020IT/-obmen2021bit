<?php

namespace App\Jobs;

use App\Models\Paysystem;
use App\Models\Tools;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ReservesReceive implements ShouldQueue, ShouldBeUnique
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $paysystems = Paysystem::whereIsActive(1)->get();
        foreach ($paysystems as $paysystem) {
            $class = $paysystem->getClass();
            if ($class !== null) {
                try {
                    $class->setReserves();
                    if (is_numeric($class->total_reserve)) {
                        $paysystem->total_reserve = $class->total_reserve;
                    }
                    if (is_numeric($class->auto_reserve)) {
                        $paysystem->auto_reserve = $class->auto_reserve;
                    }
                    //Tools::sendLogMessage("{$paysystem->class}:{$paysystem->total_reserve}");
                    $paysystem->update();
                } catch (\Throwable $exception) {
                    Tools::sendLogMessage("Произошла ошибка при получении резервов.\r\n\r\n{$exception->getMessage()}");
                }

                try {
                    $class->receive();
                } catch (\Throwable $exception) {
                    Tools::sendLogMessage("Произошла ошибка при обработке платежей.\r\n\r\n{$paysystem->class}: {$exception->getMessage()}");
                }
            }
        }
    }
}
