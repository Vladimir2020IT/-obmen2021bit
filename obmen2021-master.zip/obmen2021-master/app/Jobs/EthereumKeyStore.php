<?php

namespace App\Jobs;

use App\Models\Paysystems\Ethereum;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class EthereumKeyStore implements ShouldQueue, ShouldBeUnique
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $path = '/media/codersp/8731df2d-2d3b-4e0d-959b-73c16ce9fdb7/ethereum/keystore/';
        $newPath = '/media/codersp/8731df2d-2d3b-4e0d-959b-73c16ce9fdb7/ethereum/keystore_backup/';
        if ($handle = opendir($path)) {
            while (false !== ($entry = readdir($handle))) {
                if ($entry != '.' && $entry != '..' && mb_strpos($entry, mb_substr(Ethereum::coinbase, 2)) === false) {
                    if (filemtime($path . $entry) < time() - 86400 * 7) {
                        rename($path . $entry, $newPath . $entry);
                    }
                }
            }
        }
    }
}
