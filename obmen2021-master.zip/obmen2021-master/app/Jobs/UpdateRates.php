<?php

namespace App\Jobs;

use App\Events\RatesWereUpdated;
use App\Models\Direction;
use App\Models\Tools;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class UpdateRates implements ShouldQueue, ShouldBeUnique
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $rates;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->rates = [];
    }

    public function handleBinance() {
        $binance_data = Tools::getJsonContent('https://api.binance.com/api/v3/ticker/price',  'BINANCE TICKER');
        if ($binance_data !== null) {
            if (is_array($binance_data)) {
                foreach ($binance_data as $binance_row) {
                    if (isset($binance_row['symbol'], $binance_row['price'])) {
                        $this->rates[$binance_row['symbol']] = $binance_row['price'];
                    } else {
                        Tools::sendLogMessage("В данных BINANCE TICKER отсутствуют необходимые поля.");
                        break;
                    }
                }
            } else {
                Tools::sendLogMessage("BINANCE TICKER не является массивом.");
            }
        }
    }

    public function handleHuobi() {
        $huobi_currencies = ['bsv'];
        foreach ($huobi_currencies as $huobi_currency) {
            $symbol = "{$huobi_currency}usdt";
            $huobi_data = Tools::getJsonContent("https://api.huobi.com/market/trade?symbol=$symbol", 'HUOBI TICKER');
            if ($huobi_data !== null) {
                if (isset($huobi_data['tick']['data'][0]['price'])) {
                    $this->rates[mb_strtoupper($symbol)] = $huobi_data['tick']['data'][0]['price'];
                } else {
                    Tools::sendLogMessage("В данных HUOBI TICKER отсутствуют необходимые поля.");
                }
            }
        }
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $this->handleBinance();
        $this->handleHuobi();

        $notFounds = [];
        foreach (Direction::all() as $direction) {
            $fromCurrency = $direction->fromPaysystem->currency->id;
            $toCurrency = $direction->toPaysystem->currency->id;

            $base_rate = $this->rates[$fromCurrency . $toCurrency] ?? $this->rates[$toCurrency . $fromCurrency] ?? null;
            if ($base_rate !== null) {
                $direction->base_rate = $base_rate;
                $direction->update();
            } else {
                $notFounds[] = "$fromCurrency$toCurrency";
            }
        }

        if (count($notFounds) >= 5) {
            Tools::sendLogMessage("Не найдено курсов: " . count($notFounds));
        } elseif (count($notFounds) > 0) {
            Tools::sendLogMessage("Не найдены курсы: " . implode(', ', $notFounds));
        }

        event(new RatesWereUpdated());
    }
}
