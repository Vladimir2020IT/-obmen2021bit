<?php

namespace App\Jobs;

use App\Events\StatusChanged;
use App\Models\Exchange;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;

class Pay implements ShouldQueue, ShouldBeUnique
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        do {
            try {
                DB::beginTransaction();

                $exchange = Exchange::whereStatusId(Exchange::PAID)
                    ->whereNotNull('pay_date')
                    ->whereNull('complete_date')
                    ->limit(1)
                    ->lockForUpdate()->get()->first();

                if ($exchange !== null) {
                    $exchange->status_id = Exchange::PROCESSING;
                    $exchange->update();

                    DB::commit();

                    $info = $exchange->pay();
                    if (is_array($info) && isset($info['txid']) && !empty($info['txid'])) {
                        $exchange->status_id = Exchange::COMPLETED;
                        $exchange->complete_date = now();
                        $exchange->info = array_merge($exchange->info, $info);
                        $exchange->update();

                        event(new StatusChanged($exchange));
                    }
                } else {
                    DB::rollBack();
                }
            } catch (\Throwable $e) {
                if (DB::transactionLevel() > 0) {
                    DB::rollBack();
                }
            }
        } while ($exchange !== null);
    }
}
