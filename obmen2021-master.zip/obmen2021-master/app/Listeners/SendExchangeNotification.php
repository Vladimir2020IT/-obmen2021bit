<?php

namespace App\Listeners;

use App\Events\StatusChanged;
use App\Models\Tools;
use Mail;

class SendExchangeNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  StatusChanged  $event
     * @return void
     */
    public function handle(StatusChanged $event)
    {
        Tools::sendLogMessage("Заявка №{$event->exchange->id} " . lcfirst($event->exchange->status_name));
        Mail::to($event->exchange->form['email'])->send(new \App\Mail\StatusChanged($event->exchange));
    }
}
