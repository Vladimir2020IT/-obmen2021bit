<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;

class ValidMoneroAddress implements Rule
{
    protected $rpc;
    protected $message;

    /**
     * Create a new rule instance.
     *
     * @param $rpc
     */
    public function __construct($rpc)
    {
        $this->rpc = $rpc;
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $isValid = $this->rpc->validate_address($value);
        if ($isValid === false || !isset($isValid['valid'])) {
            $this->message = 'Не удалось проверить корректность адреса.';
            return false;
        } elseif ($isValid['valid'] === false) {
            $this->message = 'Введенный адрес является некорректным.';
        } else {
            return true;
        }
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return $this->message;
    }
}
