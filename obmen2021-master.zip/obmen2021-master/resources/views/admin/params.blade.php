@extends('adminlte::page')

@section('title', 'Параметры')

@section('content_header')
    <h1>Параметры</h1>
@stop

@section('js')
    <script>
        $("#jsGrid").jsGrid({
            width: "100%",
            filtering: true,
            editing: true,
            sorting: true,
            autoload: true,
            controller: {
                loadData: function (filter) {
                    return $.ajax({
                        type: "GET",
                        url: "/params",
                        data: filter
                    });
                },
                updateItem: function (item) {
                    item['_token'] = '{{ csrf_token() }}';
                    item['_method'] = 'PUT';

                    return $.ajax({
                        type: "POST",
                        url: "/params",
                        data: item
                    });
                }
            },
            fields: [
                {name: "id", title: "ID", type: "number", editing: false},
                {name: "name", title: "Наименование", type: "text", editing: false},
                {name: "value", title: "Значение", type: "text", editing: true},
                {type: "control", deleteButton: false}
            ]
        });
    </script>
@endsection

@section('content')
    <div id="jsGrid"></div>
@stop
