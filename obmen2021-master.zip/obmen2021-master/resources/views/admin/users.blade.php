@extends('adminlte::page')

@section('title', 'Пользователи')

@section('content_header')
    <h1>Пользователи</h1>
@stop

@section('js')
    <script>
        $("#jsGrid").jsGrid({
            width: "100%",
            filtering: true,
            editing: true,
            sorting: true,
            paging: true,
            autoload: true,
            pageSize: 20,
            pageButtonCount: 10,
            controller: {
                loadData: function (filter) {
                    return $.ajax({
                        type: "GET",
                        url: "/users",
                        data: filter
                    });
                },
                updateItem: function (item) {
                    item['_token'] = '{{ csrf_token() }}';
                    item['_method'] = 'PUT';

                    return $.ajax({
                        type: "POST",
                        url: "/users",
                        data: item
                    });
                }
            },
            fields: [
                {name: "id", title: "ID", type: "number", editing: false},
                {
                    name: "Роль",
                    title: "Role",
                    type: "select",
                    items: [
                        {"id": null, "name": ""},
                        {"id": 10, "name": "Администратор"},
                        {"id": 20, "name": "Модератор"},
                        {"id": 30, "name": "Редактор"}
                    ],
                    valueField: "id",
                    textField: "name"
                },
                {name: "name", title: "Наименование", type: "text", editing: false},
                {name: "email", title: "E-Mail", type: "text", editing: false},
                {type: "control", deleteButton: false}
            ]
        });
    </script>
@endsection

@section('content')
    <div id="jsGrid"></div>
@stop
