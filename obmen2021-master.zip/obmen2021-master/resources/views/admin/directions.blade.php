@extends('adminlte::page')

@section('title', 'Направления')

@section('content_header')
    <h1>Направления</h1>
@stop

@section('js')
    <script>
        $("#jsGrid").jsGrid({
            width: "100%",
            filtering: true,
            editing: true,
            sorting: true,
            paging: true,
            autoload: true,
            pageSize: 20,
            pageButtonCount: 10,
            controller: {
                loadData: function (filter) {
                    return $.ajax({
                        type: "GET",
                        url: "/directions",
                        data: filter
                    });
                },
                updateItem: function (item) {
                    item['_token'] = '{{ csrf_token() }}';
                    item['_method'] = 'PUT';

                    return $.ajax({
                        type: "POST",
                        url: "/directions",
                        data: item
                    });
                }
            },
            fields: [
                {name: "id", title: "ID", type: "number", editing: false},
                {name: "fromPaysystem_name", title: "ИЗ", type: "text", editing: false},
                {name: "toPaysystem_name", title: "В", type: "text", editing: false},
                {name: "base_rate", title: "Базовый курс", type: "number", editing: false},
                {name: "tariff", title: "Тариф", type: "text", editing: true},
                {name: "total_rate", title: "Курс для клиента", type: "number", editing: false},
                {name: "is_active", title: "Активный", type: "checkbox", editing: true},
                {type: "control", deleteButton: false}
            ]
        });
    </script>
@endsection

@section('content')
    <div id="jsGrid"></div>
@stop
