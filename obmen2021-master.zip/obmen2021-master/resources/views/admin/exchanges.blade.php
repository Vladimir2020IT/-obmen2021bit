@extends('adminlte::page')

@section('title', 'Заявки')

@section('content_header')
    <h1>Заявки</h1>
@stop

@section('js')
    <script>
        $("#jsGrid").jsGrid({
            width: "100%",
            filtering: true,
            editing: true,
            sorting: true,
            paging: true,
            autoload: true,
            pageSize: 20,
            pageButtonCount: 10,
            controller: {
                loadData: function (filter) {
                    return $.ajax({
                        type: "GET",
                        url: "/exchanges",
                        data: filter
                    });
                },
            },
            fields: [
                {name: "id", title: "ID", type: "number", editing: false},
                {name: "user_name", title: "Пользователь", type: "text", editing: false},
                {name: "referrer_name", title: "Реферрер", type: "text", editing: false},
                {
                    name: "status_id",
                    title: "Статус",
                    type: "select",
                    items: [
                        {"id": 10, "name": "Не оплачена"},
                        {"id": 20, "name": "Оплачена"},
                        {"id": 30, "name": "В обработке"},
                        {"id": 40, "name": "Завершена"}
                    ],
                    valueField: "id",
                    textField: "name",
                    editing: false
                },
                {name: "fromPaysystem_name", title: "ИЗ", type: "text", editing: false},
                {name: "toPaysystem_name", title: "В", type: "text", editing: false},
                {name: "from_amount", title: "К оплате", type: "number", editing: false},
                {name: "to_amount", title: "К получению", type: "number", editing: false},
                {name: "base_rate", title: "Базовый курс", type: "number", editing: false},
                {name: "tariff", title: "Тариф", type: "number", editing: false},
                {name: "total_rate", title: "Курс для клиента", type: "number", editing: false},
                {name: "create_date", title: "Создана", type: "text", editing: false},
                {name: "pay_date", title: "Оплачена", type: "text", editing: false},
                {name: "complete_date", title: "Завершена", type: "text", editing: false},
            ]
        });
    </script>
@endsection

@section('content')
    <div id="jsGrid"></div>
@stop
