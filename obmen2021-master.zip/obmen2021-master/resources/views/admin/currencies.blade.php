@extends('adminlte::page')

@section('title', 'Валюты')

@section('content_header')
    <h1>Валюты</h1>
@stop

@section('js')
    <script>
        $("#jsGrid").jsGrid({
            width: "100%",
            filtering: true,
            editing: true,
            sorting: true,
            autoload: true,
            controller: {
                loadData: function (filter) {
                    return $.ajax({
                        type: "GET",
                        url: "/currencies",
                        data: filter
                    });
                },
                updateItem: function (item) {
                    item['_token'] = '{{ csrf_token() }}';
                    item['_method'] = 'PUT';

                    return $.ajax({
                        type: "POST",
                        url: "/currencies",
                        data: item
                    });
                }
            },
            fields: [
                {name: "id", title: "Наименование", type: "text", editing: false},
                {name: "precision", title: "Знаков после запятой", type: "number", editing: false},
                {name: "pos", title: "Позиция", type: "number"},
                {type: "control", deleteButton: false}
            ]
        });
    </script>
@endsection

@section('content')
    <div id="jsGrid"></div>
@stop
