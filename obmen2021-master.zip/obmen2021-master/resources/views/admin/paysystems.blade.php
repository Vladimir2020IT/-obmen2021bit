@extends('adminlte::page')

@section('title', 'Платежные системы')

@section('content_header')
    <h1>Платежные системы</h1>
@stop

@section('js')
    <script>
        $("#jsGrid").jsGrid({
            width: "100%",
            filtering: true,
            editing: true,
            sorting: true,
            autoload: true,
            controller: {
                loadData: function (filter) {
                    return $.ajax({
                        type: "GET",
                        url: "/paysystems",
                        data: filter
                    });
                },
                updateItem: function (item) {
                    item['_token'] = '{{ csrf_token() }}';
                    item['_method'] = 'PUT';

                    return $.ajax({
                        type: "POST",
                        url: "/paysystems",
                        data: item
                    });
                }
            },
            fields: [
                {name: "id", title: "ID", type: "number", editing: false},
                {
                    name: "category_id",
                    title: "Категория",
                    type: "select",
                    items: [
                        {"id": null, "name": ""},
                        {"id": 10, "name": "Криптовалюты"},
                        {"id": 20, "name": "Токены"},
                        {"id": 30, "name": "Стейблкоины"}
                    ],
                    valueField: "id",
                    textField: "name"
                },
                {name: "currency_id", title: "Валюта", type: "text", editing: false},
                {name: "class", title: "Класс", type: "text", editing: false},
                {name: "name", title: "Наименование", type: "text", editing: false},
                {name: "total_reserve", title: "Общий резерв", type: "number", editing: false},
                {name: "auto_reserve", title: "Авто резерв", type: "number", editing: false},
                {name: "minimum", title: "Минимум", type: "text", editing: true},
                {name: "maximum", title: "Максимум", type: "text", editing: true},
                {name: "is_active", title: "Активный", type: "checkbox", editing: true},
                {name: "pos", title: "Позиция", type: "number", editing: true},
                {type: "control", deleteButton: false}
            ]
        });
    </script>
@endsection

@section('content')
    <div id="jsGrid"></div>
@stop
