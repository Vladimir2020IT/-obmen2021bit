@extends('layouts.my')

@section('content')
    <div id="exchangeView"></div>
@endsection
