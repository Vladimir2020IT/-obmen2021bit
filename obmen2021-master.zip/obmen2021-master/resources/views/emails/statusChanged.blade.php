<p>Заявка №{{ $exchange->id }} " . {{ lcfirst($exchange->status_name) }}</p>
