import React, {useEffect, useState} from 'react';
import ReactDOM from 'react-dom';
import Context from "./Context";
import CurrencyList from "./CurrencyList";
import ExchangeForm from "./ExchangeForm";

function ExchangeApp() {
    const [rates, setRates] = useState(undefined);
    const [direction, setDirection] = useState(undefined);
    const [fields, setFields] = useState(undefined);
    const [message, setMessage] = useState(null);

    useEffect(() => {
        fetch('/rates')
            .then(response => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw Error(response.statusText);
                }
            })
            .then(rates => setRates(rates))
            .catch(() => {
                setMessage(<p className='text-danger'>Не удалось загрузить данные о направлениях и тарифах!</p>);
            });
    }, []);

    useEffect(() => {
        direction !== undefined && fetch(`/fields/${direction.id}`)
            .then(response => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw Error(response.statusText);
                }
            })
            .then(fields => setFields(fields))
            .catch(() => {
                setMessage(<p className='text-danger'>Не удалось загрузить данные о выбранном направлении обмена!</p>);
            });
    }, [direction]);

    window.Echo.channel('rates')
        .listen('RatesWereUpdated', (e) => {
            setRates(e.data);
        });

    return (
        <Context.Provider value={{rates}}>
            {message}
            {rates !== undefined && <CurrencyList onDirectionSelect={setDirection}/>}
            {direction !== undefined && fields !== undefined && <ExchangeForm direction={direction} paysystems={rates.paysystems} fields={fields}/>}
        </Context.Provider>
    );
}

export default ExchangeApp;

if (document.getElementById('exchangeApp')) {
    ReactDOM.render(<ExchangeApp/>, document.getElementById('exchangeApp'));
}
