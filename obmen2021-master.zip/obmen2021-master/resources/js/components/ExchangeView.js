import React, {useEffect, useState} from 'react';
import ReactDOM from "react-dom";

function ExchangeView() {
    const [exchange, setExchange] = useState(null);
    const [message, setMessage] = useState(null);
    const path = window.location.pathname.split('/');

    useEffect(() => {
        fetch(`/exchange/${path[2]}/${path[3]}`)
            .then(response => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw Error(response.statusText);
                }
            })
            .then(exchange => {
                setExchange(exchange);
            })
            .catch(() => {
                setMessage(<p className='text-danger'>Не удалось загрузить данные о заявке!</p>);
            });
    }, []);

    window.Echo.channel(`exchange.${path[2]}.${path[3]}`)
        .listen('StatusChanged', (e) => {
            setExchange(e.exchange);
        });

    return (
        <div>
            {message}

            {exchange !== null && (
                <div>
                    <p>Заявка №{exchange.id} ({exchange.status_name}) от {exchange.create_date}</p>
                    <p>Обмен {parseFloat(exchange.from_amount)} {exchange.from_name} на {parseFloat(exchange.to_amount)} {exchange.to_name}</p>
                    <p>Оплачена: {exchange.pay_date ?? 'нет'}</p>
                    <p>Завершена: {exchange.complete_date ?? 'нет'}</p>
                    <p>Базовый курс: {parseFloat(exchange.base_rate)}</p>
                    <p>Тариф: {parseFloat(exchange.tariff)}%</p>
                    <p>Курс: {parseFloat(exchange.total_rate)}</p>

                    <p><strong>Данные пользователя:</strong></p>
                    {Object.entries(exchange.form).map(([key, value]) => {
                        return <p key={key}>{value}</p>;
                    })}
                    <p><strong>Реквизиты:</strong></p>
                    {Object.entries(exchange.requisites).map(([key, value]) => {
                        return <p key={key}>{value}</p>;
                    })}
                    {exchange.info.length > 0 &&
                    <p><strong>Информация:</strong></p> && Object.entries(exchange.info).map(([key, value]) => {
                        return <p key={key}>{value}</p>;
                    })}
                </div>
            )}
        </div>
    )
}

export default ExchangeView;

if (document.getElementById('exchangeView')) {
    ReactDOM.render(<ExchangeView/>, document.getElementById('exchangeView'));
}
