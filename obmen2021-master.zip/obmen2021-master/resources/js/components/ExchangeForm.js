import React from 'react';

class ExchangeForm extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            from_amount: '',
            to_amount: '',
            amount_field: '',
            fields: Object.keys(this.props.fields.rules).reduce((ac, a) => ({...ac, [a]: ''}), {}),
            message: '',
        };
        this.onSubmit = this.onSubmit.bind(this);
    }

    onSubmit(e) {
        e.preventDefault();

        let fields = _.clone(this.state.fields);
        fields[this.state.amount_field] = this.state[this.state.amount_field];

        fetch(`exchange/${this.props.direction.id}`, {
            method: 'POST',
            body: JSON.stringify(fields),
            'headers': {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        })
            .then(response => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw Error(response.statusText);
                }
            })
            .then(result => {
                switch (result.status) {
                    case 'success':
                        const exchange_url = `${window.location.origin}/exchangeView/${result.exchange.id}/${result.exchange.hash}`;

                        this.setState({
                            from_amount: '',
                            to_amount: '',
                            amount_field: '',
                            message: (
                                <div>
                                    <p className='text-success'>Заявка №{result.exchange.id} успешно создана!</p>
                                    <p>Постоянный адрес заявки: <a target='_blank'
                                                                   href={exchange_url}>{exchange_url}</a></p>
                                    <p>Реквизиты заявки:</p>

                                    {Object.entries(result.exchange.requisites).map(([key, value]) => {
                                        return <p key={key}>{value}</p>
                                    })}
                                </div>
                            )
                        });
                        break;
                    case 'error':
                        this.setState({
                            message: (
                                <div>
                                    {Object.entries(result.errors).map(([key, errors]) => {
                                        return <p key={key} className='text-danger'>{errors.join('<br />')}</p>
                                    })}
                                </div>
                            )
                        });
                        break;
                }
            })
            .catch(() => {
                this.setState({
                    message: (
                        <div>
                            <p className='text-danger'>Не удалось создать заявку!</p>
                        </div>
                    )
                })
            });
    }

    setFieldState(name, value) {
        const fields = this.state.fields;
        fields[name] = value;
        this.setState({fields});
    }

    removeExtraChars(str, count) {
        str = str.replace(/[^0-9.,]/g, '');
        str = str.replace(',', '.');

        let result = '';
        let wasPoint = false;
        let i;
        let d = 0;
        for (i = 0; i < str.length; i++) {
            if (str[i] === '.') {
                if (!wasPoint) {
                    wasPoint = true;
                    result += i === 0 ? '' : str[i];
                }
            } else if (wasPoint && d >= count) {
                break;
            } else if (wasPoint && d < count) {
                d++;
                result += str[i];
            } else {
                result += str[i];
            }
        }
        return result;
    }

    floor(value, precision) {
        return Math.floor(value * Math.pow(10, precision)) / Math.pow(10, precision);
    }

    ceil(value, precision) {
        return Math.ceil(value * Math.pow(10, precision)) / Math.pow(10, precision);
    }

    rate(val) {
        const value = parseFloat(val);
        return this.props.direction.inverse ?
            `${value} ${this.from.name} = 1 ${this.to.name}` :
            `1 ${this.from.name} = ${value} ${this.to.name}`;
    }

    tariff() {
        return `${parseFloat(this.props.direction.tariff)}%`;
    }

    reserve() {
        const total_reserve = this.to.total_reserve !== null ? parseFloat(this.to.total_reserve) : '~';
        const auto_reserve = this.to.auto_reserve !== null ? parseFloat(this.to.auto_reserve) : '~';
        return total_reserve === auto_reserve ? `${auto_reserve} ${this.to.name}` : `${auto_reserve} (${total_reserve}) ${this.to.name}`;
    }

    setAmount(amount_field, value) {
        let from_amount, to_amount;

        switch (amount_field) {
            case 'from_amount':
                from_amount = this.removeExtraChars(value, this.from.precision);
                to_amount = this.floor(this.props.direction.inverse ? from_amount / this.props.direction.total_rate :
                    from_amount * this.props.direction.total_rate, this.to.precision);
                to_amount = to_amount > 0 ? to_amount : '';
                break;
            case 'to_amount':
                to_amount = this.removeExtraChars(value, this.to.precision);
                from_amount = this.ceil(this.props.direction.inverse ? to_amount * this.props.direction.total_rate :
                    to_amount / this.props.direction.total_rate, this.from.precision);
                from_amount = from_amount > 0 ? from_amount : '';
                break;
            default:
                return;
        }

        this.setState({from_amount, to_amount, amount_field});
    }

    recalculate() {
        const amountFields = ['from_amount', 'to_amount'];

        if (amountFields.includes(this.state.amount_field)) {
            this.setAmount(this.state.amount_field, this.state[this.state.amount_field]);
        }
    }

    render() {
        this.from = this.props.paysystems[this.props.direction.fromPaysystem_id];
        this.to = this.props.paysystems[this.props.direction.toPaysystem_id];

        return (
            <div>
                <h1>Обмен {this.from.name} на {this.to.name}</h1>

                {this.state.message}

                <p>Базовый курс: {this.rate(this.props.direction.base_rate)}</p>
                <p>Тариф: {this.tariff()}</p>
                <p>Курс: {this.rate(this.props.direction.total_rate)}</p>
                <p>Резерв: {this.reserve()}</p>

                <form onSubmit={this.onSubmit}>
                    <div className='field'>
                        <label className='label'>Сумма к отправке</label>
                        <div className='control'>
                            <input name='from_amount' value={this.state.from_amount}
                                   onChange={e => this.setAmount(e.target.name, e.target.value)}/>
                        </div>
                    </div>
                    <div className='field'>
                        <label className='label'>Сумма к получению</label>
                        <div className='control'>
                            <input name='to_amount' value={this.state.to_amount}
                                   onChange={e => this.setAmount(e.target.name, e.target.value)}/>
                        </div>
                    </div>
                    {Object.keys(this.props.fields.rules).map(field => {
                        const label = this.props.fields.labels[field];
                        return <div key={field} className='field'>
                            <label className='label'>{label}</label>
                            <div className='control'>
                                <input name={field} value={this.state.fields[field]}
                                       onChange={e => this.setFieldState(e.target.name, e.target.value)}/>
                            </div>
                        </div>
                    })}
                    <div className='field'>
                        <div className='control'>
                            <button type='submit'>Создать заявку</button>
                        </div>
                    </div>
                </form>
            </div>
        )
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (this.props.direction !== prevProps.direction) {
            this.recalculate();
        }
    }
}

export default ExchangeForm;
