import React, {useState, useContext, useEffect} from 'react';
import Context from "./Context";

import 'react-widgets/dist/css/react-widgets.css';
import DropDownList from 'react-widgets/lib/DropdownList';

function CurrencyList({onDirectionSelect}) {
    const {rates} = useContext(Context);

    const [fromListValue, setFromListValue] = useState('');
    const [toListValue, setToListValue] = useState('');

    const fromList = Object.keys(rates.directions).map(direction_id => {
        const key = rates.directions[direction_id]['fromPaysystem_id'];
        return rates.paysystems[key];
    }).filter((value, index, self) => {
        return self.indexOf(value) === index;
    });
    if (fromList.length > 0 && !fromList.includes(fromListValue)) {
        setFromListValue(fromList[0]);
    }

    const toList = fromListValue.id !== undefined ? Object.keys(rates.directions).filter(value => {
        return rates.directions[value]['fromPaysystem_id'] === fromListValue.id;
    }).map(direction_id => {
        const key = rates.directions[direction_id]['toPaysystem_id'];
        return rates.paysystems[key];
    }).filter((value, index, self) => {
        return self.indexOf(value) === index;
    }) : [];
    if (toList.length > 0 && !toList.includes(toListValue)) {
        setToListValue(toList[0]);
    }

    const direction = fromListValue.id !== undefined && toListValue.id !== undefined ?
        rates.directions[Object.keys(rates.directions).find(value => {
            return rates.directions[value]['fromPaysystem_id'] === fromListValue.id && rates.directions[value]['toPaysystem_id'] === toListValue.id;
        })] : undefined;

    useEffect(() => {
        onDirectionSelect(direction);
    }, [direction]);

    return (
        <div>
            <p>Что отдаём:</p>
            <DropDownList
                data={fromList}
                textField='name'
                valueField='id'
                groupBy={paysystem => rates.categories[paysystem['category_id']]['name']}
                value={fromListValue}
                onChange={value => setFromListValue(value)}
            />
            <p>Что получаем:</p>
            <DropDownList
                data={toList}
                valueField='id'
                textField='name'
                groupBy={paysystem => rates.categories[paysystem['category_id']]['name']}
                value={toListValue}
                onChange={value => setToListValue(value)}
            />
        </div>
    );
}

export default CurrencyList;
